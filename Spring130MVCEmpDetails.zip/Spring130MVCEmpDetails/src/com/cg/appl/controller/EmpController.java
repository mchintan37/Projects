package com.cg.appl.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmpController {

	@RequestMapping("/employee.do")
	public ModelAndView Emp() {
	ModelAndView model=new ModelAndView("showemp");
	return model;
	}
	
	@RequestMapping("/showemp.do")
	public ModelAndView showEmp(@RequestParam("id") String empid) {
		System.out.println(empid);
		ModelAndView model=new ModelAndView();
		return model ;
		
		
		
	}
	
}
