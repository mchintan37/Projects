package com.capgemini.service;
//Creating interface for BusService and writing all the methods into it
import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;

public interface BusService {
ArrayList<BusBean> retrieveBusDetails() throws BookingException;
int bookTicket(BookingBean bookingBean) throws BookingException;
boolean updateQty(int busid,int availableseats) throws BookingException; 
}
