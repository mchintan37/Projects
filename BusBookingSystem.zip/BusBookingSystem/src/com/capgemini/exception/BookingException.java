package com.capgemini.exception;
//Creating a User Defined Exception
public class BookingException extends Exception {
	public BookingException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public BookingException(String msg){
		super(msg);
	}

}

