package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.DbUtil;

public class BusDaoImpl implements BusDao {
	Connection conn;
	PreparedStatement pstm;
	private static final Logger mylogger = Logger
			.getLogger(BusDaoImpl.class);
	
//Creating array list and storing all the bus details into it
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		
		ArrayList<BusBean> mlist=new ArrayList<BusBean>();
		System.out.println("Bus Details:");
		try {
			String query="Select * from BUSDETAILS";
			conn=DbUtil.getConnection();
			pstm=conn.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			while(res.next()) {
				int b_id=res.getInt("busid");
				String b_name=res.getString("bustype");
				String f_stop=res.getString("fromstop");
				String t_stop=res.getString("tostop");
				int fare=res.getInt("fare");
				int seat=res.getInt("availableseats");
				Date d=res.getDate("dateofjourney");
				
				BusBean b=new BusBean(); {
					b.setBusId(b_id);
					b.setBusType(b_name);
					b.setFromStop(f_stop);
					b.setToStop(t_stop);
					b.setFare(fare);
					b.setAvailableSeats(seat);
					b.setDateOfJourney(d);
					mlist.add(b);
				}
			}
		} catch(SQLException e) {
			e.printStackTrace();
			throw new BookingException("Bus Details cannot be shown");
		}
	
		try{
			pstm.close();
			conn.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	
	return mlist;
	}
//creating a method for booking ticket
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		int bookid=0;
		int bid=0;
		int upd=0;
		int busid;
		int availableseats;
		
		String query="INSERT INTO BOOKINGDETAILS VALUES (?,?,?,?)";
		bid=getBookingId();
		conn=DbUtil.getConnection();
		try {
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,bid);
			pstm.setString(2, bookingBean.getCustId());
			pstm.setInt(3, bookingBean.getBusId());
			pstm.setInt(4, bookingBean.getNoOfSeat());
			
			updateQuantity(bookingBean.getBusId(), bookingBean.getNoOfSeat());
			
			int book=pstm.executeUpdate();
			if(book==1) {
				mylogger.info("Thank You. Your Booking ID is" +bid);
				bookid=bid;
				mylogger.info("Tickets Booked Successfully");
				}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			mylogger.error("Sorry No Seats Available" +e.getMessage());
			e.printStackTrace();
			throw new BookingException("Seats Not Booked");
			
		}
		try{
			pstm.close();
			conn.close();
		} catch(SQLException e) {
			e.printStackTrace();
		}
		
		return bid;
	}
	//creating method for updating the seats quantity available

	
	
	
	private static int getBookingId() throws BookingException {
		int id=0;
		String query="SELECT BOOKING_ID_SEQ.NEXTVAL FROM DUAL";
		Connection conn=null;
		PreparedStatement pstm=null;
		
		conn=DbUtil.getConnection();
		try {
			pstm=conn.prepareStatement(query);
			ResultSet res=pstm.executeQuery();
			while(res.next()) {
				id=res.getInt(1);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return id;
	}

	public boolean updateQuantity(int busid, int availableseats)
			throws BookingException {
		int rec=0;
		String query="UPDATE BUSDETAILS SET AVAILABLESEATS=AVAILABLESEATS-? WHERE BUSID=?";
		conn=DbUtil.getConnection();
		try {
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,busid);
			pstm.setInt(2, availableseats);
			rec=pstm.executeUpdate();
			if(rec>0)
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingException("List Not Yet Updated");
		}
		return false;
		
	}
}

