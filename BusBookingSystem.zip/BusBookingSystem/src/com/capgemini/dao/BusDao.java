package com.capgemini.dao;
//Creating interface for BusDao and writing all the methods into it
import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;

public interface BusDao {

	ArrayList<BusBean>retrieveBusDetails() throws BookingException;
	int bookTicket(BookingBean bookingBean) throws BookingException;
	boolean updateQuantity(int busid,int availableseats) throws BookingException; 
}
