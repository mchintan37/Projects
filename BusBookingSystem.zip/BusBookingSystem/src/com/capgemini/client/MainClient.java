package com.capgemini.client;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;

//Creating main client class means our Main Class UI
public class MainClient {
	private static final Logger mylogger = Logger
			.getLogger(MainClient.class);
	
	public static void main(String args[]) throws BookingException {
		mylogger.info("Application Started");
		BusService busService=new BusServiceImpl();
		int choice=0;
		do {
			printDetail();
			Scanner sc=new Scanner(System.in);
			System.out.println("Please Enter Your Choice");
			choice=sc.nextInt();
			switch(choice) {
			
			case 1: //Retrieve All The Bus Details means showing bus details to user
				List<BusBean> busdetails=null;
				try {
				busdetails=busService.retrieveBusDetails();
				} catch(BookingException e) {
					e.printStackTrace();
					
				}
				for(BusBean bus:busdetails) {
					System.out.println("Bus Id is: " +bus.getBusId());
					System.out.println("Bus Type is: " +bus.getBusType());
					System.out.println("From Stop: " +bus.getFromStop());
					System.out.println("To Stop: " +bus.getToStop());
					System.out.println("Bus Fare is: " +bus.getFare());
					System.out.println("Available Seats are: " +bus.getAvailableSeats());
					System.out.println("Date of Journey is: " +bus.getDateOfJourney());
				}
			
					break;
					
			case 2: //Book Tickets as per the users wish
				 String pid="^[A-Z]{1}[0-9]{6}$";
				System.out.println("Please enter the customer ID");
				String custid=sc.next();
				try {
					BusServiceImpl.validateId(pid,custid);
				} catch(BookingException b) {
					System.out.println(b.getMessage());
				}
			
				System.out.println("Please enter the Bus ID");
				int id=sc.nextInt();
				System.out.println("Enter the number of seats to be book");
				int seats=sc.nextInt();
				
				BookingBean book=new BookingBean();
				BusBean bus=new BusBean();
				book.setCustId(custid);
				book.setBusId(id);
				book.setNoOfSeat(seats);
				int books=busService.bookTicket(book);
				
				break;
				
				case 3: //Update
				System.out.println("Enter the bus id"); 
				int ids=sc.nextInt();
				System.out.println("Enter the seats"); 
				int seatt=sc.nextInt();
				try {
					mylogger.info("Bus seats are updated");
					busService.updateQty(ids,seatt);
				} catch(BookingException b) {
					mylogger.error("Not yet updated");
					b.printStackTrace();
				}
			
				break;
					
			case 4:
				System.exit(0);
				break;
				
				default:
					System.out.println("Please Enter Right Choice");
					break;
			
			}			
		} while(choice!=4);
		}
		
		
		
		
	
	

	public static void printDetail() {
		System.out.println("**********");
		System.out.println("1. Retrieve Bus Details");
		System.out.println("2. Book Ticket");
		System.out.println("3. Update Availability");
		System.out.println("4. Exit");
					
		}
}

	
	
