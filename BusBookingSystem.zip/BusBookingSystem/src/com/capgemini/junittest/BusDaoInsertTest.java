package com.capgemini.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;

public class BusDaoInsertTest {
	BusDao bus;
	BusBean b;
	BookingBean book;

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		bus=new BusDaoImpl();
		b=new BusBean();
		book=new BookingBean();
		
	}

	@After
	public void tearDown() throws Exception {
		bus=null;
	}

	@Test
	public void test() {
		try{ 
			assertNotNull(bus.bookTicket(book));
		} catch(BookingException b) {
			b.printStackTrace();
		}
	}

}
