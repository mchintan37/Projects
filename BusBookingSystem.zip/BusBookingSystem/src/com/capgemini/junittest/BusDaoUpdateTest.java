package com.capgemini.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;

public class BusDaoUpdateTest {
BusDao bus;
	

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		bus=new BusDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		bus=null;
	}

	@Test
	public void test() {
		try{
			assertNotNull(bus.updateQuantity(1004, 5));
		} catch(BookingException b) {
			b.printStackTrace();
		}
	}

}
