package com.cg.onlineapplication.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;





import com.cg.onlineapplication.dto.Show;
import com.cg.onlineapplication.exception.ShowException;
import com.cg.onlineapplication.service.IShowService;
import com.cg.onlineapplication.service.ShowServiceImpl;

@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IShowService showService;

	public ShowController() {

	}

	public void init() throws ServletException {
		try {
			showService = new ShowServiceImpl();
		} catch (ShowException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException | ShowException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException | ShowException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException,
			SQLException, ShowException {
		String path = request.getServletPath();
		HttpSession session = request.getSession();
		if (path.equals("/showall.do")) {
			List<Show> sh;
			sh = showService.showAll();
			System.out.println(sh);
			request.setAttribute("data", sh);
			RequestDispatcher req = request
					.getRequestDispatcher("showDetails.jsp");
			req.forward(request, response);
		}
		if (path.equals("/book.do")) {
			String shownme = request.getQueryString();
			String sn = shownme.substring(5, 6);
			Show sho = showService.getShowName(sn);
			System.out.println(sho);
			request.setAttribute("prodata", sho);
			String st = request.getQueryString();
			String sm = st.substring(5, 6);
			int seat = Integer.parseInt(sm);
			Show ww = showService.getSeat(seat);
			System.out.println(ww);
			request.setAttribute("shodata", ww);
			RequestDispatcher res = request.getRequestDispatcher("bookNow.jsp");
			res.forward(request, response);
		}
		if (path.equals("/success.do")) {
			List<Show> pId = showService.showAll();
			System.out.println("Method in controller");
			
			String nn=request.getParameter("snme");
			String ny=request.getParameter("ptic");
			String ne=request.getParameter("cname");
			String no=request.getParameter("mnum");
			String ok=request.getParameter("sseats");
			String oh=request.getParameter("bbook");
			RequestDispatcher req = request.getRequestDispatcher("success.jsp");
			req.forward(request, response);
			//request.setAttribute("id", pId);
			//request.setAttribute("cid", pId);
			//request.setAttribute("did", pId);
			//request.setAttribute("mid", pId);
			//request.setAttribute("kid", pId);
			//RequestDispatcher req = request.getRequestDispatcher("success.jsp");
			//req.forward(request, response);

		}

		if (path.equals("/updatedata.do")) {
			String sname = request.getParameter("snme");
			String sseat = request.getParameter("sseats");
			RequestDispatcher req = request
					.getRequestDispatcher("showDetails.jsp");
			req.forward(request, response);
			boolean b = showService.updateSeats(sname, Integer.parseInt(sseat));
		}

	}

	public void destroy() {
		showService = null;
	}

}
