package com.cg.onlineapplication.exception;

public class ShowException extends Exception {

	public ShowException() {

	}

	public ShowException(String arg0) {
		super(arg0);

	}

	public ShowException(Throwable arg0) {
		super(arg0);

	}

	public ShowException(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}

	public ShowException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);

	}

}
