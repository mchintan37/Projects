package com.cg.onlineapplication.dao;

import java.util.List;

import com.cg.onlineapplication.dto.Show;
import com.cg.onlineapplication.exception.ShowException;

public interface IShowDao {
	public List<Show> showAll() throws ShowException;
	
	public Show getShowName(String showname);
	
	public Show getSeat (int avseats);
	
	boolean updateSeats(String showname, int avseats);
	
}
