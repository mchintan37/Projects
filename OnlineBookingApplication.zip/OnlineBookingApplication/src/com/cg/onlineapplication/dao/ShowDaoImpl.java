package com.cg.onlineapplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.onlineapplication.dto.Show;
import com.cg.onlineapplication.exception.ShowException;
import com.cg.onlineapplication.util.DbUtil;

public class ShowDaoImpl implements IShowDao {
	DbUtil util;

	public ShowDaoImpl() throws ShowException {
		util = new DbUtil();
	}

	@Override
	public List<Show> showAll() throws ShowException {
		List<Show> myList = new ArrayList<Show>();
		System.out.println("Online Ticket Booking Application");
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet res = null;
		String query = "Select SHOWID,SHOWNAME,LOCATION,SHOWDATE,AVSEATS,PRICETICKET FROM SHOWDETAILS";
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			res = pstm.executeQuery();
			while (res.next()) {
				Show s = new Show();
				s.setShowid(res.getString("showid"));
				s.setShowname(res.getString("showname"));
				s.setLocation(res.getString("location"));
				s.setShowdate(res.getDate("showdate"));
				s.setAvseats(res.getInt("avseats"));
				s.setPriceticket(res.getDouble("priceticket"));
				myList.add(s);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new ShowException("Data not displayed");
		} finally {

			try {
				if (res != null) {
					res.close();
				}
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
		}

		return myList;
	}

	@Override
	public Show getShowName(String showname) {
		String query = "Select showname,location,showdate,avseats,priceticket from showdetails where showname=?";
		Connection conn = null;
		PreparedStatement pstm = null;
		Show sh = new Show();

		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, showname);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				sh.setShowid(res.getString("showid"));
				sh.setShowname(res.getString("showname"));
				sh.setLocation(res.getString("location"));
				sh.setShowdate(res.getDate("showdate"));
				sh.setAvseats(res.getInt("avseats"));
				sh.setPriceticket(res.getDouble("priceticket"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}

		return sh;
	}

	@Override
	public Show getSeat(int avseats) {
		String query = "Select showname,location,showdate,avseats,priceticket from showdetails where avseats=?";
		Connection conn = null;
		PreparedStatement pstm = null;
		Show sho = new Show();
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, avseats);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				sho.setShowid(res.getString("showid"));
				sho.setShowname(res.getString("showname"));
				sho.setLocation(res.getString("location"));
				sho.setShowdate(res.getDate("showdate"));
				sho.setAvseats(res.getInt("avseats"));
				sho.setPriceticket(res.getDouble("priceticket"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}

		return sho;
	}

	@Override
	public boolean updateSeats(String showname, int avseats) {
		Connection conn = null;
		PreparedStatement pstm = null;
		int rec = 0;
		String query = "UPDATE SHOWDETAILS SET AVSEATS=AVSEATS-? WHERE SHOWNAME=?";
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, avseats);
			pstm.setString(2, showname);
			rec = pstm.executeUpdate();
			if (rec > 0)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}

		return false;
	}

}
