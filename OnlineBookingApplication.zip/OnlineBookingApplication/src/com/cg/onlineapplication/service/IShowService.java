package com.cg.onlineapplication.service;

import java.util.List;

import com.cg.onlineapplication.dto.Show;
import com.cg.onlineapplication.exception.ShowException;

public interface IShowService {
	public List<Show> showAll() throws ShowException;
	
	public Show getShowName(String showname);
	
	public Show getSeat(int avseats);
	
	boolean updateSeats(String showname, int avseats);
	
}
