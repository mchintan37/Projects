package com.cg.onlineapplication.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cg.onlineapplication.dao.IShowDao;
import com.cg.onlineapplication.dao.ShowDaoImpl;
import com.cg.onlineapplication.dto.Show;
import com.cg.onlineapplication.exception.ShowException;


public class ShowServiceImpl implements IShowService {
    IShowDao showDao;
	public ShowServiceImpl() throws ShowException {
	showDao=new ShowDaoImpl();
	}

	@Override
	public List<Show> showAll() throws ShowException {
		
		return showDao.showAll();
	}

	

	@Override
	public Show getSeat(int avseats) {
	
		return showDao.getSeat(avseats);
	}

	@Override
	public Show getShowName(String showname) {
		
		return showDao.getShowName(showname);
	}

	@Override
	public boolean updateSeats(String showname, int avseats) {
		
		return showDao.updateSeats(showname, avseats);
	}
	
	
}
