package com.cg.onlineapplication.dto;

import java.sql.Date;

public class Show {
	private String showid;
	private String showname;
	private String location;
	private Date showdate;
	private int avseats;
	private Double priceticket;

	public Show() {
		super();
	}

	public Show(String showid, String showname, String location, Date showdate,
			int avseats, Double priceticket) {
		super();
		this.showid = showid;
		this.showname = showname;
		this.location = location;
		this.showdate = showdate;
		this.avseats = avseats;
		this.priceticket = priceticket;
	}

	public String getShowid() {
		return showid;
	}

	public void setShowid(String showid) {
		this.showid = showid;
	}

	public String getShowname() {
		return showname;
	}

	public void setShowname(String showname) {
		this.showname = showname;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getShowdate() {
		return showdate;
	}

	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}

	public int getAvseats() {
		return avseats;
	}

	public void setAvseats(int avseats) {
		this.avseats = avseats;
	}

	public Double getPriceticket() {
		return priceticket;
	}

	public void setPriceticket(Double priceticket) {
		this.priceticket = priceticket;
	}

	@Override
	public String toString() {
		return "Show [showid=" + showid + ", showname=" + showname
				+ ", location=" + location + ", showdate=" + showdate
				+ ", avseats=" + avseats + ", priceticket=" + priceticket + "]";
	}

}
