package com.cg.flight.dao;

import java.sql.SQLException;
import java.util.List;



import com.cg.flight.dto.Booking;
import com.cg.flight.dto.Flight;
import com.cg.flight.exception.FlightException;





public interface IFlightDao {
	public int addFlight(Flight f) throws FlightException, SQLException;
	boolean updateQuantity(int flightid,String flightname,String source,String destination,int availableseats) throws FlightException; 
	public List<Flight> showAll() throws FlightException;
	public Flight getFlight(int flightid);
	int bookTicket(Booking book) throws FlightException;
	int deleteFlight (int flightId) throws FlightException;
	
}
