package com.cg.flight.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.flight.dto.Booking;
import com.cg.flight.dto.Flight;
import com.cg.flight.exception.FlightException;
import com.cg.flight.util.DbUtil;

public class FlightDaoImpl implements IFlightDao {
DbUtil util;
	public FlightDaoImpl() throws FlightException {
	util=new DbUtil();
	}

	@Override
	public int addFlight(Flight f) throws FlightException, SQLException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int sequence=0;
		int fId=0;
		String query="INSERT INTO FLIGHTDETAILS VALUES(?,?,?,?,?,?)";
		sequence=getFlightId();
		System.out.println(sequence);
		try {
			
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, sequence);
			pstm.setString(2,f.getFlightname());
			pstm.setString(3, f.getSource());
			pstm.setString(4, f.getDestination());
			pstm.setInt(5, f.getAvailableseats());
			pstm.setDate(6,f.getDateofjourney());
			System.out.println(f.getDateofjourney());
			int status = pstm.executeUpdate();
			if (status == 1) {
			fId = sequence;
				System.out.println("record is inserted");
			}
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new FlightException("Problem in Insert");
		}
		finally {		
			if (pstm != null) {
				pstm.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		
		return fId;
	}

	private int getFlightId() {
		int id = 0;
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet res=null;
		String query="SELECT FLIGHT_SEQ.NEXTVAL FROM DUAL";
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			res = pstm.executeQuery();
			while (res.next()) {
				id = res.getInt(1);
				System.out.println(id);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {	
			 
			try {
				if(res!=null){
				res.close();
				}
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
		
		
		
		return id;
	}



	@Override
	public List<Flight> showAll() throws FlightException {
		List<Flight> myList=new ArrayList<Flight>();
		System.out.println("Welcome to Air India");
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet res=null;
		String query="Select flightid,flightname,source,destination,availableseats,dateofjourney from flightdetails";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			res=pstm.executeQuery();
			while(res.next()) {
				Flight fl=new Flight();
				fl.setFlightid(res.getInt("flightid"));
				fl.setFlightname(res.getString("flightname"));
				fl.setSource(res.getString("source"));
				fl.setDestination(res.getString("destination"));
				fl.setAvailableseats(res.getInt("availableseats"));
				fl.setDateofjourney(res.getDate("dateofjourney"));
				myList.add(fl);
				
				}
			System.out.println(myList);
		return myList;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new FlightException("Data not display");
		}
		finally {	
			 
			try {
				if(res!=null){
				res.close();
				}
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
		
	
	}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	@Override
	public Flight getFlight(int flightid) {
		String query="Select flightid,flightname,source,destination,availableseats,dateofjourney from flightdetails where flightid=?";
		 Connection conn = null;
			PreparedStatement pstm = null;
		Flight fli=new Flight();
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, flightid);
			ResultSet res = pstm.executeQuery();
			while(res.next()) {
				fli.setFlightid(res.getInt("flightid"));
				fli.setFlightname(res.getString("flightname"));
				fli.setSource(res.getString("source"));
				fli.setDestination(res.getString("destination"));
				fli.setAvailableseats(res.getInt("availableseats"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return fli;
	}

	@Override
	public int bookTicket(Booking book) throws FlightException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateQuantity(int flightid, String flightname,
			String source, String destination, int availableseats)
			throws FlightException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int rec=0;
		String query="UPDATE FLIGHTDETAILS SET FLIGHTNAME=?,SOURCE=?,DESTINATION=?,AVAILABLESEATS=? WHERE FLIGHTID=?";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1, flightname);
			pstm.setString(2, source);
			pstm.setString(3,destination);
			pstm.setInt(4, availableseats);
			pstm.setInt(5,flightid);
			rec=pstm.executeUpdate();
			if(rec>0)
				return true;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public int deleteFlight(int flightId) throws FlightException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int rec=0;
		String query="DELETE FROM FLIGHTDETAILS WHERE FLIGHTID=?";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,flightId);
			rec=pstm.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flightId;
	}

}
