package com.cg.flight.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.flight.exception.FlightException;


public class DbUtil {
	private DataSource datasource;

	public DbUtil() throws FlightException {

		try {
			Context ctx = new InitialContext(); // Get Reference To Remote JNDI
			datasource = (DataSource) ctx.lookup("java:/OracleDS");
			System.out.println("Connected");
		} catch (NamingException e) {

			throw new FlightException("Failed To Get JNDI Context", e);
		}

	}

	public Connection getConnection() throws SQLException {
		return datasource.getConnection();

}
}
