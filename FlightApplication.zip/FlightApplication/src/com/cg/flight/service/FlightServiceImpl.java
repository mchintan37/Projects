package com.cg.flight.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.flight.dao.FlightDaoImpl;
import com.cg.flight.dao.IFlightDao;
import com.cg.flight.dto.Booking;
import com.cg.flight.dto.Flight;
import com.cg.flight.exception.FlightException;

public class FlightServiceImpl implements IFlightService {
IFlightDao fliDao;
	public FlightServiceImpl() throws FlightException {
	fliDao=new FlightDaoImpl();
	}

	@Override
	public int addFlight(Flight f) throws FlightException, SQLException {
		// TODO Auto-generated method stub
		return fliDao.addFlight(f) ;
	}


	@Override
	public List<Flight> showAll() throws FlightException {
		// TODO Auto-generated method stub
		return fliDao.showAll();
	}

	@Override
	public Flight getFlight(int flightid) {
		// TODO Auto-generated method stub
		return fliDao.getFlight(flightid);
	}

	@Override
	public int bookTicket(Booking book) throws FlightException {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<String> isValidated(Flight f) {
		List<String> errorList = new ArrayList<String>();

		Pattern pattern = null;
		Matcher matcher = null;

		// Product Name Validation
		pattern = Pattern.compile("^[A-Za-z]{3,25}$");
		matcher = pattern.matcher(f.getFlightname());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Flight Name!!!!");
		}

		// Phone Number Validation
		//if (donor.getPhoneNumber() <= 999999999) {
			//errorList.add("Please enter a valid Phone Number");
		//}
		
		
		//Product Description Validation!
		pattern = Pattern.compile("^[A-Z]{3,25}$");
		matcher = pattern.matcher(f.getSource());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Product Description!!!!");
		}
		return errorList;
	}

	@Override
	public boolean updateQuantity(int flightid, String flightname,
			String source, String destination, int availableseats)
			throws FlightException {
		// TODO Auto-generated method stub
		return fliDao.updateQuantity(flightid, flightname, source, destination, availableseats);
	}

	@Override
	public int deleteFlight(int flightId) throws FlightException {
		
		return fliDao.deleteFlight(flightId);
	}

}
