package com.cg.flight.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.flight.dto.Flight;
import com.cg.flight.exception.FlightException;
import com.cg.flight.service.FlightServiceImpl;
import com.cg.flight.service.IFlightService;

@WebServlet({ "/FlightController", "*.do" })
public class FlightController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       IFlightService flightService;
       FlightServiceImpl fs;
    
    public FlightController() {
    }

	
	public void init() throws ServletException {
		try {
			flightService=new FlightServiceImpl();
		} catch (FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fs=new FlightServiceImpl();
		} catch (FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public void destroy() {
		flightService=null;
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException | FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException | FlightException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, SQLException, FlightException {
		String path = request.getServletPath();
		HttpSession session=request.getSession();
		if (path.equals("/flightadd.do")) {
			List<String> errorlist=new ArrayList<String>();
			Flight f=new Flight();
			String fname=request.getParameter("fname");
			String fsou=request.getParameter("fsource");
			String fdes=request.getParameter("fdest");
			String fsea=request.getParameter("fseat");
			String dates=request.getParameter("datee");
			int seat=Integer.parseInt(fsea);
			Date d=java.sql.Date.valueOf(java.time.LocalDate.parse(dates));
			System.out.println(dates);
			
			f.setFlightname(fname);
			f.setSource(fsou);
			f.setDestination(fdes);
			f.setAvailableseats(seat);
			f.setDateofjourney(d);
			System.out.println(fname);
			errorlist=fs.isValidated(f);
		
			
				try {
					int fid=flightService.addFlight(f);
					System.out.println("In Controller");
					request.setAttribute("id", fid);
					RequestDispatcher req = request
							.getRequestDispatcher("welcome.jsp");
					req.forward(request, response);
				} catch (Exception e) {
					System.out.println(e);
				request.setAttribute("errorMsg", "Sorry Error Occured");
				RequestDispatcher req=request.getRequestDispatcher("error.jsp");
				req.forward(request, response);
					
				}
		}
				if(path.equals("/showall.do")) {
					List<Flight> fl=flightService.showAll();
					System.out.println(fl);
					request.setAttribute("data",fl);
					RequestDispatcher req=request.getRequestDispatcher("showAll.jsp");
					req.forward(request, response);	
				}
			
			if(path.equals("/update.do")) {
				System.out.println("Updated..!!!");
				String id=request.getQueryString();
				String fid=id.substring(3);
				int ids=Integer.parseInt(fid);
				Flight fg=flightService.getFlight(ids);
				System.out.println(fg);
				request.setAttribute("prodata",fg);
				RequestDispatcher res=request.getRequestDispatcher("updateflight.jsp");
				res.forward(request, response);
			}
			if(path.equals("/updatedata.do")) {
				String fname=request.getParameter("fname");
				String source=request.getParameter("fsrc");
				String dest=request.getParameter("fdest");
				String seat=request.getParameter("fseat");
				String ids=request.getParameter("fid");
				
				boolean bs=flightService.updateQuantity(Integer.parseInt(ids),fname, source, dest, Integer.parseInt(seat));
				
			} if(path.equals("/delete.do")) {
				String id=request.getParameter("id");
				System.out.println(id);
				int in=flightService.deleteFlight(Integer.parseInt(id));
				System.out.println(in);
				request.setAttribute("prodatas", in);
				RequestDispatcher res=request.getRequestDispatcher("delete.jsp");
				res.forward(request, response);
				
				
			}
			
		}
        
}



