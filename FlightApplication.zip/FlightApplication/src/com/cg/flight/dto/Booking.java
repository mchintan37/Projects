package com.cg.flight.dto;

public class Booking {
private int bookingid;
private String custid;
private int flightid;
public Booking(int bookingid, String custid, int flightid) {
	super();
	this.bookingid = bookingid;
	this.custid = custid;
	this.flightid = flightid;
}
public Booking() {
	super();
}
public int getBookingid() {
	return bookingid;
}
public void setBookingid(int bookingid) {
	this.bookingid = bookingid;
}
public String getCustid() {
	return custid;
}
public void setCustid(String custid) {
	this.custid = custid;
}
public int getFlightid() {
	return flightid;
}
public void setFlightid(int flightid) {
	this.flightid = flightid;
}
@Override
public String toString() {
	return "Booking [bookingid=" + bookingid + ", custid=" + custid
			+ ", flightid=" + flightid + "]";
}


}
