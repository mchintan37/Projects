package com.cg.flight.dto;

import java.sql.Date;

public class Flight {
private int flightid;
private String flightname;
private String source;
private String destination;
private int availableseats;
private Date dateofjourney;
public Flight() {
	super();
}
public Flight(int flightid, String flightname, String source,
		String destination, int availableseats, Date dateofjourney) {
	super();
	this.flightid = flightid;
	this.flightname = flightname;
	this.source = source;
	this.destination = destination;
	this.availableseats = availableseats;
	this.dateofjourney = dateofjourney;
}
public int getFlightid() {
	return flightid;
}
public void setFlightid(int flightid) {
	this.flightid = flightid;
}
public String getFlightname() {
	return flightname;
}
public void setFlightname(String flightname) {
	this.flightname = flightname;
}
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getDestination() {
	return destination;
}
public void setDestination(String destination) {
	this.destination = destination;
}
public int getAvailableseats() {
	return availableseats;
}
public void setAvailableseats(int availableseats) {
	this.availableseats = availableseats;
}
public Date getDateofjourney() {
	return dateofjourney;
}
public void setDateofjourney(Date dateofjourney) {
	this.dateofjourney = dateofjourney;
	
}
@Override
public String toString() {
	return "Flight [flightid=" + flightid + ", flightname=" + flightname
			+ ", source=" + source + ", destination=" + destination
			+ ", availableseats=" + availableseats + ", dateofjourney="
			+ dateofjourney + "]";
}
}
