package com.cg.appl.service;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Service;

import com.cg.appl.dao.IProductDao;
import com.cg.appl.dto.Product;
import com.cg.appl.exception.ProductException;
@Service("productService")
public class ProductServiceImpl implements IProductService {

	private IProductDao dao;
	@Resource(name="productDao")
	public void setDao(IProductDao dao) {
		this.dao=dao;
	}
	

	@Override
	public Product getProductDetails(int productId) throws ProductException {
		try {
			Product product = dao.getProductDetails(productId); 
			if(product==null)
			{
				 throw new ProductException("Check Your details");
			}
			return product;
		}
		 catch (ProductException e) {
			throw new ProductException("Check Your details");
		 }
		
	}
	

	@Override
	public List<Product> getAllProduct() throws ProductException {

		return dao.getAllProduct();
	}

	@Override
	public Product insertNewProduct(Product product) throws ProductException,
			RollbackException {

		return dao.insertNewProduct(product);
	}


	@Override
	public Product updateProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		return dao.updateProduct(product);
	}


	@Override
	public boolean Delete(int productId) throws ProductException {
		// TODO Auto-generated method stub
		return dao.Delete(productId);
	}

}
