package com.cg.appl.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.dto.Product;
import com.cg.appl.exception.ProductException;
import com.cg.appl.service.IProductService;

@Controller
public class ProductController {
	private IProductService service;
	List<String> description;
	List<String> location;
	
	@PostConstruct
	public void initialize() {
		description = new ArrayList<>();
		description.add("Homemade");
		description.add("Readymade");
		description.add("Ayurvedic");
		description.add("Natural");
		
		location=new ArrayList<>();
		location.add("Mumbai");
		location.add("Pune");
		location.add("Bangalore");
	}
	@Resource(name = "productService")
	public void setProductService(IProductService service) {
		this.service = service;
	}

	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage() {
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}
	
	@RequestMapping("/enterProductNo.do")
	public ModelAndView enterTraineeNo() {
		ModelAndView model = new ModelAndView("enterProductNo"); // JSP file
																	// name..!!
		return model;
	}
	
	@RequestMapping("/getProductDetails.do")
	public ModelAndView getProductDetails(@RequestParam("id") int productId) {
		System.out.println(productId);
		Product product;
		ModelAndView model = null;
		try {
			product=service.getProductDetails(productId);			
			System.out.println(product);
			model=new ModelAndView("getProductDetails");
			model.addObject("getProduct",product);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			model = new ModelAndView("error");
			model.addObject("message", e.getMessage());
			model.addObject("msg", "Check!!!!!");
			e.printStackTrace();
		}
		
		return model;
	}
	
	@RequestMapping("/listAllProduct.do")
	public ModelAndView listAllProduct() {
		ModelAndView model = null;
		try {
			List<Product> products=service.getAllProduct();
			model=new ModelAndView("listAllProduct");
			model.addObject("product",products);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			model = new ModelAndView("error");
			model.addObject("message", e.getMessage());
			
		}
		
		return model;
	}
	
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm() {
		ModelAndView model = new ModelAndView("entryForm");
		
		model.addObject("product", new Product());
		model.addObject("descript", description);
		model.addObject("loco",location);
		return model;
	}
	
	@RequestMapping("/onSubmit.do")
	public ModelAndView getsubmitEntryForm(
			@ModelAttribute("product") @Valid Product product, BindingResult result) {
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()) {
			model.addObject("descript", description);
			model.addObject("loco",location);
			//model.addAttribute("trainee",new Trainee());
			model.setViewName("entryForm");
			return model;
		}
		try {
			Product produ=service.insertNewProduct(product);
			model = new ModelAndView("successInsert");
			model.addObject("product", produ);
			return model;
		} catch (ProductException e) {
			model.setViewName("error");
			model.addObject("error",
					"Record Insertion Failed:" + e.getMessage());
			return model;
		}
	}
	
	@RequestMapping("/updateForm.do")
	public ModelAndView getUpdateForm(@RequestParam("id") int productId) throws ProductException {
		
			ModelAndView model=new ModelAndView();
			try {
				Product product=service.getProductDetails(productId);
				model = new ModelAndView("updateForm");
				
				model.addObject("product", product);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				model.setViewName("error");
				model.addObject("error",
						"Record Insertion Failed:" + e.getMessage());
			}	
		return model;
	}
	
	@RequestMapping("/submitUpdateForm")
	public ModelAndView getsubmitUpdateForm(
			@ModelAttribute("product") @Valid Product product, BindingResult result) {
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()) {
			model.addObject("descript", description);
			//model.addAttribute("trainee",new Trainee());
			model.setViewName("entryForm");
			return model;
		}
		try {
			Product produc=service.updateProduct(product);
			model = new ModelAndView("successUpdate");
			model.addObject("product", produc);
			return model;
		} catch (ProductException e) {
			model.setViewName("error");
			model.addObject("error",
					"Record Insertion Failed:" + e.getMessage());
			return model;
		}
	}
	
	@RequestMapping("/delete.do")
	public ModelAndView getDeleteForm(@RequestParam("id") int productId) throws ProductException {
		ModelAndView model=new ModelAndView();
		boolean pro=service.Delete(productId);
		
		
		return model;
	}
	
		
	}	

	
