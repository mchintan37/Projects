package com.cg.appl.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity(name = "product")
@Table(name = "PRODUCT")
@SequenceGenerator(name = "product_generate", sequenceName = "PRODTS_SEQ", allocationSize = 1, initialValue = 1004)
public class Product {
	private int productId;
	private String productName;
	private int productPrice;
	private int productQuantity;
	private String description;
	private Date productDate;
	private String location;

	public Product() {
		super();
	}

	@Id
	@Column(name = "PRODUCT_ID")
	@GeneratedValue(generator = "product_generate", strategy = GenerationType.SEQUENCE)
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	@NotNull(message = "Please write product name!")
	@Size(min = 1, max = 10, message = "Name must be of the above size!!")
	@Column(name = "PRODUCT_NAME")
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	//@NotNull(message = "Please write product price!")
	//@Size(min = 1, max = 10, message = "enter properly!")
	@Column(name = "PRODUCT_PRICE")
	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	//@NotNull(message = "Please write product quantity!")
	//@Size(min = 1, max = 10, message = "enter proper quantity!")

	@Column(name = "PRODUCT_QUANTITY")
	@Size(min=1, max=1000, message="")
	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	//@NotNull(message = "Please write product description!")
	//@Size(min = 1, max = 10, message = "enter properly description!")
	@Column(name = "DESCRIPTION")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	@Column(name="PRODUCT_DATE")
	public Date getProductDate() {
		return productDate;
	}

	public void setProductDate(Date productDate) {
		this.productDate = productDate;
	}
	@Column(name="LOCATION")
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName="
				+ productName + ", productPrice=" + productPrice
				+ ", productQuantity=" + productQuantity + ", description="
				+ description + ", productDate=" + productDate + ", location="
				+ location + "]";
	}

}
