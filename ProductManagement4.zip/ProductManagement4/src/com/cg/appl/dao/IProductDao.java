package com.cg.appl.dao;

import java.util.List;

import javax.persistence.RollbackException;

import com.cg.appl.dto.Product;

import com.cg.appl.exception.ProductException;



public interface IProductDao {

	Product getProductDetails(int productId) throws ProductException;
	List<Product> getAllProduct() throws ProductException;
	Product insertNewProduct(Product product) throws ProductException, RollbackException;
	public Product updateProduct(Product product) throws ProductException;
	boolean Delete(int productId) throws ProductException;
}
