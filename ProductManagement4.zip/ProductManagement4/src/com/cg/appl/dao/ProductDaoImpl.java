package com.cg.appl.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.dto.Product;
import com.cg.appl.exception.ProductException;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao {
	private EntityManagerFactory factory;

	@Resource(name = "entityManagerFactory")
	public void setFactory(EntityManagerFactory factory) {
		this.factory = factory;
	}

	@Override
	public Product getProductDetails(int productId) throws ProductException {
		EntityManager manager = factory.createEntityManager();
		Product product = manager.find(Product.class, productId);

		if (product != null) {
			System.out.println("record found..!!");
		} else {
			System.out.println("record not found..!!");
		}
		return product;
	}

	@Override
	public List<Product> getAllProduct() throws ProductException {
		String query = "select p from product p";
		EntityManager manager = factory.createEntityManager();
		Query qrys = manager.createQuery(query, Product.class);
		return qrys.getResultList();
	}

	@Override
	public Product insertNewProduct(Product product) throws ProductException,
			RollbackException {
		EntityManager manager = factory.createEntityManager();
		try {
			EntityTransaction trans = manager.getTransaction();
			trans.begin();
			manager.persist(product);
			trans.commit();
		} catch (RollbackException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
		return product;
	}

	@Override
	public Product updateProduct(Product product) throws ProductException {
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		manager.merge(product);
		manager.getTransaction().commit();
		return product;
	}

	@Override
	public boolean Delete(int productId) throws ProductException {
		EntityManager manager = factory.createEntityManager();
			manager.getTransaction().begin();
			Product product=manager.find(Product.class, productId);
			manager.remove(product);
			manager.getTransaction().commit();
		
		return false;
	}

}
