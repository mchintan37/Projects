package com.cg.productz.exception;

public class ProductzException extends Exception {

	public ProductzException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public ProductzException(String msg){
		super(msg);
	}

}
