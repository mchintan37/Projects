package com.cg.productz.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.productz.dao.IProductzDao;
import com.cg.productz.dao.ProductzDaoImpl;
import com.cg.productz.dto.Productz;
import com.cg.productz.exception.ProductzException;

public class TestProductzDaoImpl {
	IProductzDao iProductz;
	

	@Before
	public void beforeTest() throws Exception {
		iProductz=new ProductzDaoImpl();
	}

	@After
	public void afterTest()  {
		iProductz=null;
	}

	@Test
	public void doTest() throws ProductzException {
		assertNotNull(iProductz.showAllData());
	}

}
