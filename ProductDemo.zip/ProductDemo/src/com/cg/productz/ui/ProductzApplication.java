package com.cg.productz.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.productz.dto.Productz;
import com.cg.productz.exception.ProductzException;
import com.cg.productz.service.IProductzService;
import com.cg.productz.service.ProductzServiceImpl;

public class ProductzApplication {
public static void main(String args[]) throws ProductzException { 
	IProductzService prodService=new ProductzServiceImpl();
	int choice=0;
	do{
		printDetail();
		Scanner sc=new Scanner(System.in);
		choice=sc.nextInt();
		switch(choice) {
		case 1://ADD 
			
		/*System.out.println("Enter product ID");
		int pid=sc.nextInt();*/
		String patt="^[A-Z]{1}[a-z]{1,8}";
		sc.nextLine();
		System.out.println("Enter product name");
		String pname=sc.nextLine();
		try {
		ProductzServiceImpl.validateName(patt,pname);
		} catch(ProductzException p1) {
			System.out.println(p1.getMessage());
			break;
		}
		System.out.println("Enter product price");
		int price=sc.nextInt();
		System.out.println("Enter product description");
		String desc=sc.next();
		
	Productz p=new Productz();
	//p.setProductid(pid);
	p.setProductname(pname);
	p.setProductprice(price);
	p.setProductdesc(desc);
	try{
	prodService.addProductz(p);
		} catch(ProductzException p1) {
			p1.printStackTrace();
			System.out.println(p1.getMessage());
		}
	break;
	
		case 2://Show All Products
			List<Productz> myList=null;
			try{
				myList=prodService.showAll();
			} catch(ProductzException p2) {
				p2.printStackTrace();
			}
			for (Productz prod:myList) {
				System.out.println("Product Id is" +prod.getProductid());
				System.out.println("Product Name is" +prod.getProductname());
				System.out.println("Product Price is" +prod.getProductprice());
				System.out.println("Product Description is" +prod.getProductdesc());
			}
			break;
			
			case 3://Search Products
				System.out.println("Enter products id");
				int pids=sc.nextInt();
				Productz psearch=null;
				try{
					psearch=prodService.searchProductz(pids);
				} catch (ProductzException p3) {
					p3.printStackTrace();
				}
			if(psearch.getProductid()!=0) {
				System.out.println("Product id is" +psearch.getProductid());
				System.out.println("Product name is" +psearch.getProductname());
				System.out.println("Product price is" +psearch.getProductprice());
				System.out.println("Product description is" +psearch.getProductdesc());
			}
			else{
				System.out.println("Product id is not correct");
			}
			break;
			
			case 4: //Remove Products
				System.out.println("Enter products id");
				int idProduct=sc.nextInt();
				prodService.deleteprod(idProduct);
				break;
				
			case 5: //Exit
				
				break;
				
	}
	} while(choice!=5);
}
public static void printDetail(){
	System.out.println("**********");
	System.out.println("1. Add Products");
	System.out.println("2. Show All Products");
	System.out.println("3. Search Products");
	System.out.println("4. Remove Products ");
	System.out.println("5. Exit");
	System.out.println("***********");
}
}




