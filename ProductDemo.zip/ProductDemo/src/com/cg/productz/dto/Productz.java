package com.cg.productz.dto;

public class Productz {
	private int productid;
	private String productname;
	private int productprice;
	private String productdesc;

	public Productz() {
		super();
	}

	public Productz(int productid, String productname, int productprice,
			String productdesc) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productprice = productprice;
		this.productdesc = productdesc;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}

	public String getProductdesc() {
		return productdesc;
	}

	public void setProductdesc(String productdesc) {
		this.productdesc = productdesc;
	}

	@Override
	public String toString() {
		return "Productz [productid=" + productid + ", productname="
				+ productname + ", productprice=" + productprice
				+ ", productdesc=" + productdesc + "]";
	}

}
