package com.cg.productz.service;

import java.util.List;
import java.util.regex.Pattern;


import com.cg.productz.dao.IProductzDao;
import com.cg.productz.dao.ProductzDaoImpl;
import com.cg.productz.dto.Productz;
import com.cg.productz.exception.ProductzException;

public class ProductzServiceImpl implements IProductzService {
IProductzDao productzDao=new ProductzDaoImpl();

	public Productz addProductz(Productz p) throws ProductzException {
		// TODO Auto-generated method stub
		return productzDao.addDataProductz(p);
	}

	public List<Productz> showAll() throws ProductzException {
		// TODO Auto-generated method stub
		return productzDao.showAllData();
	}

	public Productz searchProductz(int productid) throws ProductzException {
		// TODO Auto-generated method stub
		return productzDao.searchData(productid);
	}

	public boolean deleteprod(int productid) throws ProductzException {
		// TODO Auto-generated method stub
		return productzDao.deleteProduct(productid);
	}
	public static void validateName
	(String patt,String name) throws ProductzException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new ProductzException("Name should be min 3 max 10 with First letter capital");
	}
	}
}
