package com.cg.productz.service;

import java.util.List;

import com.cg.productz.dto.Productz;
import com.cg.productz.exception.ProductzException;

public interface IProductzService {
public Productz addProductz(Productz p) throws ProductzException;
public List<Productz> showAll() throws ProductzException;
public Productz searchProductz(int productid) throws ProductzException;
boolean deleteprod(int productid) throws ProductzException;
}
