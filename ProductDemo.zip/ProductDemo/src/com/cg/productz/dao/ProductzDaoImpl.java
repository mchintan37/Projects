package com.cg.productz.dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.productz.dto.Productz;
import com.cg.productz.exception.ProductzException;
import com.cg.productz.util.DbUtil;

public class ProductzDaoImpl implements IProductzDao {
	Connection conn = null;
	PreparedStatement pstm = null;
	private static final Logger mylogger = Logger
			.getLogger(ProductzDaoImpl.class);

	public Productz addDataProductz(Productz p) throws ProductzException {
		// TODO Auto-generated method stub
		int productid = 0;
		int pid = 0;

		String query = "INSERT INTO PRODUCTZ VALUES(?,?,?,?)";
		pid=getProductId();
		conn = DbUtil.getConnection();
		try {
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, pid);
			pstm.setString(2, p.getProductname());
			pstm.setInt(3, p.getProductprice());
			pstm.setString(4, p.getProductdesc());

			int status=pstm.executeUpdate();
			if (status == 1) {
				mylogger.info("Product ID is" + pid);
				productid = pid;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			mylogger.error("Data not inserted" + e.getMessage());
			throw new ProductzException("Data not inserted");
			/* e.printStackTrace(); */
		}
		try {
			pstm.close();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return p;
	}

	public List<Productz> showAllData() throws ProductzException {
		// TODO Auto-generated method stub
		List<Productz> myList = new ArrayList<Productz>();
		System.out.println("Product Management");

		try {
			String query = "select * from productz";
			conn = DbUtil.getConnection();
			pstm = conn.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				Productz pr = new Productz();
				pr.setProductid(res.getInt("productid"));
				pr.setProductname(res.getString("productname"));
				pr.setProductprice(res.getInt("productprice"));
				pr.setProductdesc(res.getString("productdesc"));
				myList.add(pr);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProductzException("Data not displayed");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return myList;
	}

	public Productz searchData(int productid) throws ProductzException {
		Connection conn = null;
		PreparedStatement pstm = null;
		Productz psearch = new Productz();
		String query = "SELECT * from PRODUCTZ where productid=?";
		conn = DbUtil.getConnection();
		try {
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, productid);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {

				psearch.setProductid(res.getInt("productid"));
				psearch.setProductname(res.getString("productname"));
				psearch.setProductprice(res.getInt("productprice"));
				psearch.setProductdesc(res.getString("productdesc"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProductzException("Could Not Search");
		} finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}

		return psearch;
	}

	public boolean deleteProduct(int productid) throws ProductzException {
		conn=DbUtil.getConnection();
		int rec=0;
		String query="DELETE FROM PRODUCTZ WHERE productid=?";
		try {
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,productid);
			rec=pstm.executeUpdate();
			if(rec>0)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProductzException("Could Not Delete");
		}
		
		return false;
	}

	public static int getProductId() {
		int id=0;
		String query="SELECT prod_seq.NEXTVAL FROM DUAL";
		Connection conn=null;
		PreparedStatement pstm=null;
			
			try {
				conn=DbUtil.getConnection();
				pstm=conn.prepareStatement(query);
				ResultSet res=pstm.executeQuery();
				while(res.next()){
					id=res.getInt(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ProductzException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return id;
			}
		
		
	}
/*	public static void main(String args[]) throws ProductzException {
		PropertyConfigurator.configure("log4j.properties");
		mylogger.info("Application Started");
		ProductzDaoImpl impl = new ProductzDaoImpl();
		List<Productz> mlist=impl.showAllData();
		for(Productz m:mlist){
			System.out.println(m);
		}
		System.out.println(impl.searchData(1004));

	}*/
	
