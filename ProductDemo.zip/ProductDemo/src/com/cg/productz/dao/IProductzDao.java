package com.cg.productz.dao;

import java.util.List;

import com.cg.productz.dto.Productz;
import com.cg.productz.exception.ProductzException;

public interface IProductzDao  {
public Productz addDataProductz(Productz p) throws ProductzException;
public List<Productz> showAllData() throws ProductzException; 
public Productz searchData(int productid) throws ProductzException;
boolean deleteProduct (int productid) throws ProductzException;
}
