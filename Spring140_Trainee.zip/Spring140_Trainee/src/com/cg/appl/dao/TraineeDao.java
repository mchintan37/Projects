package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

public interface TraineeDao {

	Trainee getTraineeDetails(int traineeId) throws TraineeException;
	List<Trainee> getAllTrainee() throws TraineeException;
}
