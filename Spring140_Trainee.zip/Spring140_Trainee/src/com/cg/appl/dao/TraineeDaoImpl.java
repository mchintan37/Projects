package com.cg.appl.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDao {
	private EntityManagerFactory factory;

	@Resource(name = "entityManagerFactory")
	// name should be in xml..!!
	public void setFactory(EntityManagerFactory factory) {
		this.factory = factory;
	}

	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		EntityManager manager = factory.createEntityManager();
		Trainee trainee = manager.find(Trainee.class, traineeId);
		if (trainee != null) {
			System.out.println("record found");
			return trainee;
		} else {
			System.out.println("not found");
			return null;
		}

	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		String qry = "select t from trainee t";
		EntityManager manager = factory.createEntityManager();
		Query qrys = manager.createQuery(qry, Trainee.class);

		return qrys.getResultList();
	}

}
