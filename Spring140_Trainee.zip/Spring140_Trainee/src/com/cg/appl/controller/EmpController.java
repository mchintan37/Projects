package com.cg.appl.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.service.TraineeService;

@Controller
public class EmpController {
	private TraineeService service;

	@Resource(name = "traineeService")
	public void setTraineeService(TraineeService service) { // /Services
															// Injection...!!!
		this.service = service;
	}

	@RequestMapping("/enterTraineeNo.do")
	public ModelAndView enterTraineeNo() {
		ModelAndView model = new ModelAndView("enterTraineeNo"); //JSP file name..!!
		return model;
	}

	@RequestMapping("/getTraineeDetails.do")
	public ModelAndView getTraineeDetails(@RequestParam("id") int traineeNo) {
		System.out.println(traineeNo);
		Trainee trainee;
		ModelAndView model = null;
		try {
			trainee = service.getTraineeDetails(traineeNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails", trainee);
		} catch (TraineeException e) {
			// TODO Auto-generated catch block
			model = new ModelAndView("error");
			model.addObject("message", e.getMessage());
		}

		return model;

	}

	@RequestMapping("/listAllTrainee.do")
	public ModelAndView listAllTrainee() {
		ModelAndView model = null;
		try {
			List<Trainee> trainees = service.getAllTrainee();
			model = new ModelAndView("listAllTrainee");
			model.addObject("trainees", trainees);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("message", e.getMessage());
		}

		return model;

	}

}
