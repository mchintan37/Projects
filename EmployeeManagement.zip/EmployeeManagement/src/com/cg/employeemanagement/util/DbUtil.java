package com.cg.employeemanagement.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.employeemanagement.exception.EmployeeException;

public class DbUtil {

	private DataSource datasource;

	public DbUtil() throws EmployeeException {

		try {
			Context ctx = new InitialContext(); // Get Reference To Remote JNDI
			datasource = (DataSource) ctx.lookup("java:/OracleDS");
			System.out.println("Connected");
		} catch (NamingException e) {

			throw new EmployeeException("Failed To Get JNDI Context", e);
		}

	}

	public Connection getConnection() throws SQLException {
		return datasource.getConnection();

	}
}
