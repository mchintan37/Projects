package com.cg.employeemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;
import com.cg.employeemanagement.util.DbUtil;




public class EmployeeDaoImpl implements IEmployeeDao {

	DbUtil util;

	public EmployeeDaoImpl() throws EmployeeException {
		util = new DbUtil();
	}

	@Override
	public int addEmployee(Employee emp) throws SQLException, EmployeeException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int sequence = 0;
		int empId = 0;
		String query = "INSERT INTO EMPLOYEEMANAGEMENT VALUES (?,?,?,?)";
		sequence = getEmployeeId();
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, sequence);
			pstm.setString(2, emp.getEmpName());
			pstm.setString(3, emp.getEmpQualification());
			pstm.setDouble(4, emp.getEmpSalary());

			int status = pstm.executeUpdate();
			if (status == 1) {
				empId = sequence;
				System.out.println("record is inserted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Problem in Insert");
		}

		finally {
			if (pstm != null) {
				pstm.close();
			}
			if (conn != null) {
				conn.close();
			}

		}
		return empId;
	}

	public int getEmployeeId() {
		int id = 0;
		Connection conn = null;
		PreparedStatement pstm = null;
		String query = "SELECT empid_sequence.NEXTVAL FROM DUAL";
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				id = res.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		List<Employee> myList = new ArrayList<Employee>();
		System.out.println("Employee Management!!!");
		Connection conn = null;
		PreparedStatement pstm = null;
		String query = "Select emp_id,emp_name,emp_qual,emp_sal from employeemanagement";
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				Employee emp = new Employee();
				emp.setEmpId(res.getInt("emp_id"));
				emp.setEmpName(res.getString("emp_name"));
				emp.setEmpQualification(res.getString("emp_qual"));
				emp.setEmpSalary(res.getDouble("emp_sal"));
				myList.add(emp);

			}
		} catch (SQLException e) {
			throw new EmployeeException("Data Not Displayed");
		} finally {
			if (pstm != null) {
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

		return myList;
	}

	@Override
	public Employee getEmployee(int id) {
		String query = "Select emp_id,emp_name,emp_qual,emp_sal from employeemanagement where emp_id=?";
		Connection conn = null;
		PreparedStatement pstm = null;
		Employee em = new Employee();
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, id);
			ResultSet res = pstm.executeQuery();

			while (res.next()) {
				em.setEmpId(res.getInt("emp_id"));
				em.setEmpName(res.getString("emp_name"));
				em.setEmpQualification(res.getString("emp_qual"));
				em.setEmpSalary(res.getDouble("emp_sal"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return em;
	}
	
	@Override
	public boolean updateQty(int empId,String empName, String empQualification,
			String empSalary) throws EmployeeException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int rec=0;
		String query="UPDATE EMPLOYEEMANAGEMENT SET EMP_NAME=?,EMP_QUAL=?,EMP_SAL=? WHERE EMP_ID=?";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,empName);
			pstm.setString(2,empQualification);
			pstm.setString(3,empSalary);
			pstm.setInt(4, empId);
			rec=pstm.executeUpdate();
			if(rec>0)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Data not found");
		}
		return false;
	}

	@Override
	public boolean deleteEmployee(int empId) throws EmployeeException {
		Connection conn = null;
		PreparedStatement pstm = null;
		
		int rec=0;
		String query="DELETE FROM EMPLOYEEMANAGEMENT WHERE EMP_ID=?";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,empId);
			rec=pstm.executeUpdate();
			if(rec>0)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Could Not Delete");
		}
		
		return false;
	}




	
}
