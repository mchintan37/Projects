package com.cg.employeemanagement.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;




public interface IEmployeeDao {
	public int addEmployee(Employee emp) throws SQLException, EmployeeException;

	public List<Employee> showAll() throws EmployeeException;
	
	public Employee getEmployee(int id);
	
	boolean updateQty(int empId,String empName,String empQualification,String empSalary) throws EmployeeException; 
	
	boolean deleteEmployee (int empId) throws EmployeeException;
}
