package com.cg.employeemanagement.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;
import com.cg.employeemanagement.service.EmployeeServiceImpl;
import com.cg.employeemanagement.service.IEmployeeService;

@WebServlet("*.do")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IEmployeeService employeeService;

	public EmployeeController() {

	}

	public void init(ServletConfig config) throws ServletException {
		try {
			employeeService = new EmployeeServiceImpl();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void destroy() {
		employeeService = null;

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException,
			EmployeeException {
		String path = request.getServletPath();
		// EMPL is added on index.jsp page, if found on that then this method
		// run and goes forward to addEmployee page!
		if (path.equals("/empl.do")) {
			RequestDispatcher res = request
					.getRequestDispatcher("addEmployee.jsp");
			res.forward(request, response);
		}
		// EMPADD is written in the addEmployee page in the action, when that
		// runs add details method runs!
		if (path.equals("/empadd.do")) {
			Employee emp = new Employee();
			String name = request.getParameter("ename");
			String qual = request.getParameter("equal");
			String sal = request.getParameter("esal");
			emp.setEmpName(name);
			emp.setEmpQualification(qual);
			emp.setEmpSalary(Double.parseDouble(sal));

			try {
				int empId = employeeService.addEmployee(emp);
				request.setAttribute("id", empId);
				RequestDispatcher req = request
						.getRequestDispatcher("welcome.jsp");
				req.forward(request, response);
			} catch (SQLException | EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} if (path.equals("/showall.do"))
		{
		List<Employee> empl;
		empl = employeeService.showAll();
		 System.out.println(empl);
		request.setAttribute("data", empl);
		RequestDispatcher req = request.getRequestDispatcher("showAll.jsp");
        req.forward(request,response);
		}
		if(path.equals("/update.do")){
			System.out.println("Update ..........!!!");
			String id=request.getQueryString();
			String empid=id.substring(3, 7);
			int ids=Integer.parseInt(empid);
			Employee empl=employeeService.getEmployee(ids);
			//System.out.println(empl);
			request.setAttribute("empdata", empl);
			RequestDispatcher res=request.getRequestDispatcher("updateemployee.jsp");
			res.forward(request, response);
			//System.out.println(id);
			/*Employee e=new Employee();
			e.setEmpId(Integer.parseInt(id));*/
		}
		if(path.equals("/updatedata.do")) {
			String name=request.getParameter("ename");
			String quali=request.getParameter("quals");
			String sala=request.getParameter("sala");
			String id=request.getParameter("ids");
			
			
		boolean rs=employeeService.updateQty(Integer.parseInt(id),name,quali,sala);
			
		}
		
		if(path.equals("/delete.do")) {
			System.out.println("hii");
			String id=request.getParameter("id");
			//System.out.println(id);
			boolean re=employeeService.deleteEmployee(Integer.parseInt(id));
			RequestDispatcher res=request.getRequestDispatcher("delete.jsp");
			res.forward(request, response);
			
		}
	}
}
