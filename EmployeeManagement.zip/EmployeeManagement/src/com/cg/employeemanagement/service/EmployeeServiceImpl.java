package com.cg.employeemanagement.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.employeemanagement.dao.EmployeeDaoImpl;
import com.cg.employeemanagement.dao.IEmployeeDao;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	IEmployeeDao empDao;

	public EmployeeServiceImpl() throws EmployeeException {
		empDao = new EmployeeDaoImpl();
	}

	@Override
	public int addEmployee(Employee emp) throws SQLException, EmployeeException {

		return empDao.addEmployee(emp);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		return empDao.showAll();
	}
	

	@Override
	public Employee getEmployee(int id) {
		// TODO Auto-generated method stub
		return empDao.getEmployee(id);
	}

	@Override
	public boolean updateQty(int empId, String empName,
			String empQualification, String empSalary) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.updateQty(empId, empName, empQualification, empSalary);
	}

	@Override
	public boolean deleteEmployee(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.deleteEmployee(empId);
	}

	
	}


	
	


