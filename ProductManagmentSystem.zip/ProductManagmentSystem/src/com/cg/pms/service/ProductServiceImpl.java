package com.cg.pms.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.pms.dao.IProductDao;
import com.cg.pms.dao.ProductDaoImpl;
import com.cg.pms.dto.Product;
import com.cg.pms.exception.ProductException;

public class ProductServiceImpl implements IProductService {

	IProductDao prodDao=new ProductDaoImpl();
	@Override
	public int addProduct(Product pro) throws ProductException {
		// TODO Auto-generated method stub
		return prodDao.addProduct(pro);
	}

	@Override
	public List<Product> showall() throws ProductException {
		// TODO Auto-generated method stub
		System.out.println("in service...");
		return prodDao.showall();
	}

	@Override
	public Product searchProduct(int prodId) throws ProductException {
		// TODO Auto-generated method stub
		return prodDao.searchProduct(prodId);
	}

	@Override
	public void removeProduct(int prodId) {
		// TODO Auto-generated method stub
		
	}
	
	public static boolean 
	validateName(String prodName,String prodPattern) throws ProductException{
		
	boolean validation=Pattern.matches(prodPattern,prodName);
	if(!validation){
throw new ProductException("First Letter should be capital min3 max20");
	}
	
	return validation;
	
	
	}

}
