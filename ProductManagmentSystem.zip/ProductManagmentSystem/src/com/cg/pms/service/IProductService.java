package com.cg.pms.service;

import java.util.List;

import com.cg.pms.dto.Product;
import com.cg.pms.exception.ProductException;

public interface IProductService {
	
	public int addProduct(Product pro) throws ProductException;
	public List<Product> showall() throws ProductException;
	public Product searchProduct(int prodId) throws ProductException;
	public void removeProduct(int prodId);

}
