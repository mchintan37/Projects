package com.cg.pms.junittest;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.pms.dao.ProductDaoImpl;
import com.cg.pms.dto.Product;
import com.cg.pms.exception.ProductException;

public class ProductDaoTest {

	
	Product prod=null;
	ProductDaoImpl prodDao=null;
	@Before
	public void callBefore(){
		prod=new Product();
		prod.setProductName("aaaa");
		prod.setProductPrice(11111);
		prod.setProductDes("rrrrr");
		prodDao=new ProductDaoImpl();
	}
	@Test
	public void myTestCase() throws ProductException{
		assertEquals(1016,prodDao.addProduct(prod));
		
	}
	@After
	public void callAfter(){
		
	}

}
