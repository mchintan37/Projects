package com.cg.appl.dao;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cg.appl.util.DbUtil;
import com.cg.appl.util.DbUtilImpl;
@Repository("entityDao")
public class EntityDao {
	private DbUtil dbUtil;

	
	public EntityDao() {
		System.out.println("In constructor of entity dao");
	}
	@PostConstruct
	public void setUp() {
		System.out.println("In setup of dao");
	}
	@PreDestroy
	public void cleanUp() {
		System.out.println("in cleanup of dao");
	}
	
	
@Autowired
//@Qualifier("dbUtil1"
		//+ "")
@Resource(name="dbUtil")
	public void setDbUtil(DbUtil dbUtil) {
		System.out.println(("Dsadsa"));
		this.dbUtil = dbUtil;
	}

	public void getConnection() {
		dbUtil.getConnection();
	}

}
