package com.cg.appl.util;

import java.sql.Connection;

public class JndiUtil implements DbUtil {
	
	public JndiUtil() {
		System.out.println("In constructor jndi util");
	}

	@Override
	public Connection getConnection() {
		System.out.println("in jndi get connection");
		return null;
	}

}
