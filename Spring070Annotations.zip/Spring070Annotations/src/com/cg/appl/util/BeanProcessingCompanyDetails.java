package com.cg.appl.util;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class BeanProcessingCompanyDetails implements BeanPostProcessor {
 
	@Override
	public Object postProcessAfterInitialization(Object arg0, String arg1)
			throws BeansException {
			System.out.println("IN AFTER INIT...");
		return null;
	}

	@Override
	public Object postProcessBeforeInitialization(Object arg0, String arg1)
			throws BeansException {
System.out.println("IN BEFORE INIT!!!!!!!!!!!!!!");
		return null;
	}

}
