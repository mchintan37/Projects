package com.cg.appl.util;

import java.sql.Connection;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class DbUtilImpl implements DbUtil, InitializingBean,DisposableBean,ApplicationContextAware {

	public void setUp() {
		System.out.println("In SetUp()");
	}

	public void cleanUp() {
		System.out.println("In cleanup");
	}

	public DbUtilImpl() {
		System.out.println("in constructor of dbUtil");
	}

	public void setX(int x) {
		System.out.println("in Setx");
	}
	
	
	@Override
	public Connection getConnection() {
		// TODO Auto-generated method stub
		System.out.println("In get connection");
		return null;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("In after properties Set!");
	}

	@Override
	public void destroy() throws Exception {
	System.out.println("In destroy!!!!");
		
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0)
			throws BeansException {
		System.out.println("in appl context aware!!!!!");
		
	}

}
