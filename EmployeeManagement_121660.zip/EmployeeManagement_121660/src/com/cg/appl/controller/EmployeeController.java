package com.cg.appl.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.dto.Employee;
import com.cg.appl.exception.EmployeeException;
import com.cg.appl.service.IEmployeeService;

@Controller
public class EmployeeController {
	private IEmployeeService service;
	List<String> designation;            //creating list of designation to show drop down
	List<String> gender;				//creating list of gender to show select one in radio button

	@PostConstruct
	public void initialize() {
		designation = new ArrayList<>();               //creating new arrayList for designation
		designation.add("Software Engineer");			//adding values
		designation.add("Senior Software Engineer");
		designation.add("Team Lead");
		designation.add("Manager");

		gender = new ArrayList<>();                     //creating new arrayList for gender
		gender.add("Male");								//adding values
		gender.add("Female");

	}

	@Resource(name = "employeeService")							//injecting service into controller
	public void setEmployeeService(IEmployeeService service) {
		this.service = service;
	}

	@RequestMapping("/welcome.do")								
	public ModelAndView getWelcomePage() {
		ModelAndView model = new ModelAndView("welcome");		//will send it to welcome.jsp page
		return model;
	}

	@RequestMapping("/entryForm.do")		
	public ModelAndView getEntryForm() {
		ModelAndView model = new ModelAndView("entryForm");		//will send it to entryForm.jsp page
		model.addObject("employee", new Employee());					//adding Employee object
		model.addObject("design", designation);							//adding designation object
		model.addObject("genders", gender);								//adding gender object

		return model;

	}

	@RequestMapping("/onSubmit.do")											
	public ModelAndView getsubmitEntryForm(
			@ModelAttribute("employee") @Valid Employee employee,				
			BindingResult result) throws EmployeeException {			//Valid used to bring validation into effect
		ModelAndView model = new ModelAndView();
		if (result.hasErrors()) {
			model.addObject("design", designation);						
			model.addObject("genders", gender);
			model.setViewName("entryForm");								//will send it to entryForm page
			return model;
		}
		try {
			Employee emp = service.insertNewEmployee(employee);				//calling insert method from service
			model = new ModelAndView("successInsert");					//will send it to successInsert jsp page
			model.addObject("employee", emp);
			return model;
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Could Not Add");				//throwing user defined exception
		}
	}

	@RequestMapping("/listAllEmployee.do")									
	public ModelAndView listAllEmployee() throws EmployeeException {	
		ModelAndView model = null;
		try {
			List<Employee> employee = service.showAllEmployee();		//calling showAll method from service
			model = new ModelAndView("listAllEmployee");						//sending it to listAllEmployee.jsp page
			model.addObject("employee", employee);	
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Could Not Show All Details");			//throwing user defined exception
		}
		return model;
	}
}
