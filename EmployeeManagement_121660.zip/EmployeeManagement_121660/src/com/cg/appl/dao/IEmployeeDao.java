package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.dto.Employee;
import com.cg.appl.exception.EmployeeException;

public interface IEmployeeDao {

	Employee insertNewEmployee(Employee employee) throws EmployeeException;  //method for Inserting/adding new employee

	List<Employee> showAllEmployee() throws EmployeeException; //method for Showing details of all employee
}
