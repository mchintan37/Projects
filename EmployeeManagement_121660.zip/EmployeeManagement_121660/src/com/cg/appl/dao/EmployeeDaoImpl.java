package com.cg.appl.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.dto.Employee;

import com.cg.appl.exception.EmployeeException;

@Repository("employeeDao")														//giving a name to the dao which will be used in service
public class EmployeeDaoImpl implements IEmployeeDao {							//implementing the interface
	private EntityManagerFactory factory;										//creating EntityManagerFactory

	@Resource(name = "entityManagerFactory")									//creating resource for entityManagerFactory
	public void setFactory(EntityManagerFactory factory) {
		this.factory = factory;
	}

	@Override
	public Employee insertNewEmployee(Employee employee)							//insert/add Employee method
			throws EmployeeException {
		EntityManager manager = factory.createEntityManager();				//creating entityManagerFactory
		try {
			EntityTransaction trans = manager.getTransaction();				//creating Transaction
			trans.begin();													//Beginning the transaction
			manager.persist(employee);	
			trans.commit();													//commit the transaction to show effect
		} catch (RollbackException e) {
			e.printStackTrace();
		}
		return employee;
	}

	@Override
	public List<Employee> showAllEmployee() throws EmployeeException {			//showAll employee method
		String query = "select e from employee e";							//query written to show all emp details
		EntityManager manager = factory.createEntityManager();					//creating Entitymanager object
		Query qrys = manager.createQuery(query, Employee.class);
		return qrys.getResultList();
	}

}
