package com.cg.appl.exception;

public class EmployeeException extends Exception {       //extends the Exception superclass to bring all the constructors from it

	public EmployeeException() {

	}

	public EmployeeException(String arg0) {
		super(arg0);

	}

	public EmployeeException(Throwable arg0) {
		super(arg0);

	}

	public EmployeeException(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}

	public EmployeeException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);

	}

}
