package com.cg.appl.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity(name = "employee")										//entity name given to bean/dto class
@Table(name = "EMPLOYEE")											//table name present in database given here
@SequenceGenerator(name = "emp_generate", sequenceName = "HIBERNATE_SEQUENCE", allocationSize = 1, initialValue = 1001)
																			//sequence generated here
public class Employee {
	private int employeeCode;
	private String employeeName;
	private String employeeGender;
	private String designationName;
	private String employeeEmail;
	private String employeePhone;

	public Employee() {															//default constructor is made here
		super();
	}
	
	@Id																			//id annotation given
	@Column(name="EMPLOYEE_CODE")													//column name of database given
	@GeneratedValue(generator = "emp_generate", strategy = GenerationType.SEQUENCE)		//sequence generated
	public int getEmployeeCode() {
		return employeeCode;
	}																				//getter and setters used

	public void setEmployeeCode(int employeeCode) {
		this.employeeCode = employeeCode;
	}
	
	
	@NotNull(message="Please write name of appropriate size!")						//validation message given
	@Size(min = 1, max = 40, message = "Name must be of the above size!!")					//validation message and limit given
	@Column(name="EMPLOYEE_NAME")													//column name of database given
	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {								//getters and setter used
		this.employeeName = employeeName;
	}

	@NotEmpty(message="Please Select Gender")									//Not empty used so that field cannot remain empty
	@Column(name="EMPLOYEE_GENDER")													//column name of database written
	public String getEmployeeGender() {
		return employeeGender;
	}
																					//getters and setters used
	public void setEmployeeGender(String employeeGender) {
		this.employeeGender = employeeGender;
	}
	
	@NotEmpty(message="Please Select Designation")							//not empty used so field cannot remain empty
	@Column(name="DESIGNATION_NAME")											//column name of database written
	public String getDesignationName() {
		return designationName;
	}
																					//getters and setters used
	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}
	
	@Email(message="Invalid Email Format!")										//Email validation is used and message given
	@Column(name="EMPLOYEE_EMAIL")													//column name of database written
	public String getEmployeeEmail() {
		return employeeEmail;
	}
																							//getters and setters used
	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}
	@Size(min=7,max=10,message="Phone Number Should Accept Only 10 digits")						//phone no validation done
	@Pattern(regexp = "^[0-9]+$", message = "Phone Number should contain only 10 digits")		//regular expression used
	@Column(name="EMPLOYEE_PHONE")															//column name of database written
	public String getEmployeePhone() {
		return employeePhone;
	}
																						//getters and setter used
	public void setEmployeePhone(String employeePhone) {
		this.employeePhone = employeePhone;
	}

	@Override																				//To string is used
	public String toString() {
		return "Employee [employeeCode=" + employeeCode + ", employeeName="
				+ employeeName + ", employeeGender=" + employeeGender
				+ ", designationName=" + designationName + ", employeeEmail="
				+ employeeEmail + ", employeePhone=" + employeePhone + "]";
	}

}
