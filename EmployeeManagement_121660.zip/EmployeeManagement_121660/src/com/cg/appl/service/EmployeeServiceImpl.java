package com.cg.appl.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cg.appl.dao.IEmployeeDao;
import com.cg.appl.dto.Employee;
import com.cg.appl.exception.EmployeeException;

@Service("employeeService")                                     //giving name to service class which will be used in Controller
public class EmployeeServiceImpl implements IEmployeeService {     //implementing the service interface

	private IEmployeeDao dao;											//initializing the dao interface

	@Resource(name = "employeeDao")										//using the name written in dao here to bring changes
	public void setDao(IEmployeeDao dao) {
		this.dao = dao;
	}

	@Override
	public Employee insertNewEmployee(Employee employee)								//insert/add method
			throws EmployeeException {

		return dao.insertNewEmployee(employee);
	}

	@Override
	public List<Employee> showAllEmployee() throws EmployeeException {				//showAll employee method

		return dao.showAllEmployee();
	}

}
