package com.cg.appl.service;

import java.util.List;

import com.cg.appl.dto.Employee;
import com.cg.appl.exception.EmployeeException;

public interface IEmployeeService {

	Employee insertNewEmployee(Employee employee) throws EmployeeException; //method for inserting/adding new employee

	List<Employee> showAllEmployee() throws EmployeeException;  //method for showing details of all the employee
}
