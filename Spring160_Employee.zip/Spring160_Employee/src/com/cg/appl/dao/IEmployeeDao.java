package com.cg.appl.dao;


	
	import java.util.List;

import javax.persistence.RollbackException;

import com.cg.appl.entities.Emp;
import com.cg.appl.exception.EmpException;

	


	public interface IEmployeeDao {
		Emp getEmpDetails(int empId) throws EmpException;
		List<Emp> getAllEmp() throws EmpException;
		Emp insertNewEmp(Emp emp) throws EmpException, RollbackException;
		Emp updateEmp(Emp emp) throws EmpException, RollbackException;
	}

