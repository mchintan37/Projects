package com.cg.appl.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity(name = "employee")
@Table(name = "EMP")
@NamedQueries({
		@NamedQuery(name = "qryEmpOnSal", query = "select e from employee e where empsal between :from and :to"),
		@NamedQuery(name = "qryAllEmps", query = "select e from employee as e"),
		@NamedQuery(name = "qryEmpComm", query = "select e from employee e where commission is not null") })
@SequenceGenerator(name = "emp_generate", sequenceName = "EMP_SEQ", allocationSize = 1, initialValue = 1)
public class Emp implements Serializable {
	private static final long serialVersionUID = 1L;
	private int empno;
	private String empname;
	private Float empsal;
	private Float commission;
	//private Float totalsalary;

	@Id
	@Column(name = "EMPNO")
	@GeneratedValue(generator = "emp_generate", strategy = GenerationType.SEQUENCE)
	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	@Column(name = "COMM")
	public Float getCommission() {
		return commission;
	}

	public void setCommission(Float commission) {
		this.commission = commission;
	}

	@Column(name = "ENAME")
	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	@Column(name = "SAL")
	public Float getEmpsal() {
		return empsal;
	}

	public void setEmpsal(Float empsal) {
		this.empsal = empsal;
	}

	@Transient
	// @Column(name="SAL+COMM")
	public Float getTotalsalary() {
		return getEmpsal() + (getCommission()==null ? 0: getCommission());
	}

	/*
	 * public void setTotalsalary(Float totalsalary) { this.totalsalary =
	 * totalsalary;
	 */
	// }

	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", empname=" + empname + ", empsal="
				+ empsal + ", commission=" + commission + ", totalsalary="
				+ getTotalsalary()  + "]";
	}

}
