package com.cg.appl.service;

import java.util.List;

import javax.persistence.RollbackException;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

public interface TraineeService {
	Trainee getTraineeDetails(int traineeId) throws TraineeException;
	List<Trainee> getAllTrainee() throws TraineeException;
	Trainee insertNewTrainee(Trainee trainee) throws TraineeException, RollbackException;
}
