package com.cg.appl.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.service.TraineeService;

@Controller
public class EmpController {
	private TraineeService service;
	List<String> domainList;
	List<String> locations;

	@PostConstruct
	public void initialize() {
		domainList = new ArrayList<>();
		domainList.add("Java");
		domainList.add("Dotnet");
		domainList.add("Cobol");
		domainList.add("Database");
		domainList.add("Analytics");

		locations = new ArrayList<>();
		locations.add("Pune");
		locations.add("Mumbai");
		locations.add("Kolkata");
		locations.add("Hyderabad");
		locations.add("Banglore");
	}

	@Resource(name = "traineeService")
	public void setTraineeService(TraineeService service) { // /Services
															// Injection...!!!
		this.service = service;
	}

	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage() {
		ModelAndView model = new ModelAndView("welcome"); // JSP file name..!!
		return model;
	}

	@RequestMapping("/enterTraineeNo.do")
	public ModelAndView enterTraineeNo() {
		ModelAndView model = new ModelAndView("enterTraineeNo"); // JSP file
																	// name..!!
		return model;
	}

	@RequestMapping("/getTraineeDetails.do")
	public ModelAndView getTraineeDetails(@RequestParam("id") int traineeNo) {
		System.out.println(traineeNo);
		Trainee trainee;
		ModelAndView model = null;
		try {
			trainee = service.getTraineeDetails(traineeNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails", trainee);
		} catch (TraineeException e) {
			// TODO Auto-generated catch block
			model = new ModelAndView("error");
			model.addObject("message", e.getMessage());
		}

		return model;

	}

	@RequestMapping("/listAllTrainee.do")
	public ModelAndView listAllTrainee() {
		ModelAndView model = null;
		try {
			List<Trainee> trainees = service.getAllTrainee();
			model = new ModelAndView("listAllTrainee");
			model.addObject("trainees", trainees);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("message", e.getMessage());
		}

		return model;

	}

	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm() {
		ModelAndView model = new ModelAndView("entryForm"); // JSP file name..!!

		model.addObject("trainee", new Trainee());
		model.addObject("domains", domainList);
		model.addObject("locations", locations);
		return model;
	}

	@RequestMapping("/submitEntryForm.do")
	public ModelAndView getsubmitEntryForm(
			@ModelAttribute("trainee") @Valid Trainee trainee, BindingResult result) {
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()) {
			//model.addAttribute("trainee",new Trainee());
			model.addObject("domains", domainList);
			model.addObject("locations", locations);
			model.setViewName("entryForm");
			return model;
		}
		try {
			Trainee traineeResponse = service.insertNewTrainee(trainee);
			model = new ModelAndView("successInsert"); // JSP file
			// name..!!
			model.addObject("trainee", traineeResponse);
			return model;
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("error",
					"Record Insertion Failed:" + e.getMessage());
			return model;
		}
	}
		@RequestMapping("/updateTrainee.do")
		public ModelAndView updateTrainee(@RequestParam("id") int traineeNo) {
			System.out.println(traineeNo);
			Trainee trainee;
			ModelAndView model = null;
			model = new ModelAndView("error");
			model.addObject("message","Dummy Message");
			
			/*try {
				trainee = service.getTraineeDetails(traineeNo);
				model = new ModelAndView("traineeDetails");
				model.addObject("traineeDetails", trainee);
			} catch (TraineeException e) {
				// TODO Auto-generated catch block
				model = new ModelAndView("error");
				model.addObject("message", e.getMessage());
			}
*/
			return model;

		}

		
	}


