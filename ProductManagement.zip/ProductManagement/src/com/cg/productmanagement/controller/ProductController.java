package com.cg.productmanagement.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import javax.servlet.http.HttpSession;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.exception.ProductException;
import com.cg.productmanagement.service.IProductService;
import com.cg.productmanagement.service.ProductServiceImpl;

@WebServlet("*.do")
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IProductService productService;
	ProductServiceImpl ps;

	public ProductController() {

	}

	public void init() throws ServletException {
		try {
			productService = new ProductServiceImpl();
			ps=new ProductServiceImpl();
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException | ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException | ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, SQLException, ProductException {
		String path = request.getServletPath();
		
		/*if (path.equals("/prod.do")) {
			RequestDispatcher res = request
					.getRequestDispatcher("addProduct.jsp");
			res.forward(request, response);
		}*/
		HttpSession session=request.getSession();
		if (path.equals("/prodadd.do")) {
			List<String> errorlist=new ArrayList<String>();
			Product p = new Product();
			String pname = request.getParameter("pname");
			String pdesc = request.getParameter("pdesc");
			String pqtys = request.getParameter("pqt");
			String pprices = request.getParameter("pprice");
			String dates=request.getParameter("datee");
			int pqty=Integer.parseInt(pqtys);
			int price=Integer.parseInt(pprices);
			Date d=java.sql.Date.valueOf(java.time.LocalDate.parse(dates));
			System.out.println(dates);
			
			p.setProductname(pname);
			p.setProductdesc(pdesc);
			p.setProductqty(pqty);
			p.setProductprice(price);
			p.setProductdate(d);
			errorlist=ps.isValidated(p);
			if(errorlist.isEmpty())
			{
				try {
					int pId = productService.addProduct(p);
					System.out.println("Method in controller");
					request.setAttribute("id", pId);
					RequestDispatcher req = request
							.getRequestDispatcher("welcome.jsp");
					req.forward(request, response);
				} catch (ProductException e) {
					// TODO Auto-generated catch block
					request.setAttribute("errorMsg", "Sorry, Some Error Occured!");
					RequestDispatcher req=request.getRequestDispatcher("error.jsp");
					req.forward(request, response);
				}
				
			}
			else
			{
				session.setAttribute("errorList", errorlist);
				RequestDispatcher req=request.getRequestDispatcher("error.jsp");
				req.forward(request, response);
			}
		} if(path.equals("/showall.do")) {
			List<Product> p;
			p=productService.showAll();
			System.out.println(p);
			request.setAttribute("data",p);
			RequestDispatcher req=request.getRequestDispatcher("showAll.jsp");
			req.forward(request, response);
		} 
		if(path.equals("/update.do")){
			System.out.println("Update...!!");
			String id=request.getQueryString();
			String pid=id.substring(3, 7);
			int ids=Integer.parseInt(pid);
			Product pro=productService.getProduct(ids);
			System.out.println(pro);
			request.setAttribute("prodata", pro);
			RequestDispatcher res=request.getRequestDispatcher("updateproduct.jsp");
			res.forward(request, response);
			
		}
		if(path.equals("/updatedata.do")) {
			String pname = request.getParameter("pname");
			String pdesc = request.getParameter("pdesc");
			String pqtys = request.getParameter("pqty");
			String pprices = request.getParameter("pprice");
			String ids =request.getParameter("pid");
			
			boolean b=productService.updateQty(Integer.parseInt(ids), pname, pdesc, Integer.parseInt(pqtys), Integer.parseInt(pprices));
		}
		if(path.equals("/delete.do")) {
			String id=request.getParameter("id");
			System.out.println(id);
			int boo=productService.deleteProduct(Integer.parseInt(id));
			System.out.println(boo);
			request.setAttribute("prodatas", boo);
			RequestDispatcher res=request.getRequestDispatcher("delete.jsp");
			res.forward(request, response);
			
		
		}
			
		}
		
	

	public void destroy() {
		productService = null;
	}

}
