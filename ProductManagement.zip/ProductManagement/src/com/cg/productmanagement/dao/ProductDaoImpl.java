package com.cg.productmanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.exception.ProductException;
import com.cg.productmanagement.util.DbUtil;

public class ProductDaoImpl implements IProductDao {
	DbUtil util;

	public ProductDaoImpl() throws ProductException {
		util = new DbUtil();
	}

	@Override
	public int addProduct(Product p) throws ProductException, SQLException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int sequence=0;
		int pId=0;
		String query="INSERT INTO PRODUCTMANAGEMENT VALUES(?,?,?,?,?,?)";
	
		
		try {
			sequence=getProductId();
			System.out.println(sequence);
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setInt(1, sequence);
			pstm.setString(2,p.getProductname());
			pstm.setString(3,p.getProductdesc());
			pstm.setInt(4, p.getProductqty());
			pstm.setInt(5, p.getProductprice());
			//Calendar c =Calendar.getInstance();
			//java.sql.Date currentDate=new java.sql.Date(c.getTime().getTime());
			pstm.setDate(6,p.getProductdate());
			System.out.println(p.getProductname());
			int status = pstm.executeUpdate();
			if (status == 1) {
			pId = sequence;
				System.out.println("record is inserted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new ProductException("Problem in Insert");
		}
		finally {		
			if (pstm != null) {
				pstm.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		
		return pId;
	}

	public int getProductId() {
		int id = 0;
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet res=null;
		String query = "SELECT prodid_seq.NEXTVAL FROM DUAL";
		try {
			conn = util.getConnection();
			pstm = conn.prepareStatement(query);
			res = pstm.executeQuery();
			while (res.next()) {
				id = res.getInt(1);
				System.out.println(id);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {	
			 
				try {
					if(res!=null){
					res.close();
					}
					if (pstm != null) {
						pstm.close();
					}
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			}
			
		
		return id;
	}
		

	@Override
	public List<Product> showAll() throws ProductException {
    List<Product> myList =new ArrayList<Product>();
    System.out.println("Product Management");
    Connection conn = null;
	PreparedStatement pstm = null;
	ResultSet res=null;
	String query="Select prodid, prodname, proddesc,prodqty,prodprice,proddate from productmanagement";
	try {
		conn=util.getConnection();
		pstm=conn.prepareStatement(query);
		res=pstm.executeQuery();
		while(res.next()) {
			Product pro=new Product();
			pro.setProductid(res.getInt("prodid"));
			pro.setProductname(res.getString("prodname"));
			pro.setProductdesc(res.getString("proddesc"));
			pro.setProductqty(res.getInt("prodqty"));
			pro.setProductprice(res.getInt("prodprice"));
			//Calendar c =Calendar.getInstance();
			//java.sql.Date currentDate=new java.sql.Date(c.getTime().getTime());
			//pro.setProductdate(res.getDate("proddate"));
			pro.setProductdate(res.getDate("proddate"));
			myList.add(pro);
			
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		throw new ProductException("Data not displayed");
	}
	finally {	
		 
		try {
			if(res!=null){
			res.close();
			}
			if (pstm != null) {
				pstm.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
		return myList;
	
	}
	@Override
	public Product getProduct(int productid) {
    String query="Select prodid, prodname, proddesc,prodqty,prodprice from productmanagement where prodid=?";
    Connection conn = null;
	PreparedStatement pstm = null;
	Product p=new Product();
	try {
		conn = util.getConnection();
		pstm = conn.prepareStatement(query);
		pstm.setInt(1, productid);
		ResultSet res = pstm.executeQuery();
		
		while(res.next()) {
		p.setProductid(res.getInt("prodid"));	
		p.setProductname(res.getString("prodname"));
		p.setProductdesc(res.getString("proddesc"));
		p.setProductqty(res.getInt("prodqty"));
		p.setProductprice(res.getInt("prodprice"));
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return p;
	}

	@Override
	public boolean updateQty(int productid, String productname,
			String productdesc, int productqty, int productprice)
			throws ProductException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int rec=0;
		String query="UPDATE PRODUCTMANAGEMENT SET PRODNAME=?,PRODDESC=?,PRODQTY=?,PRODPRICE=? WHERE PRODID=?";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1, productname);
			pstm.setString(2, productdesc);
			pstm.setInt(3,productqty);
			pstm.setInt(4, productprice);
			pstm.setInt(5, productid);
			rec=pstm.executeUpdate();
			if(rec>0)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public int deleteProduct(int productId) throws ProductException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int rec=0;
		String query="DELETE FROM PRODUCTMANAGEMENT WHERE PRODID=?";
		try {
			conn=util.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,productId);
			rec=pstm.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return productId;
	}
	
	


}
