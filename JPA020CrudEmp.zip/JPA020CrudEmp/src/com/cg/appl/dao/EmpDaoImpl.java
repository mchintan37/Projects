package com.cg.appl.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import com.cg.appl.entities.Emp;
import com.cg.appl.exception.EmpException;
import com.cg.appl.util.EntityManageUtil;

public class EmpDaoImpl implements IEmpDao {
	private EntityManageUtil util;
	private EntityManager manager;
	private DriverManager manager;
	public EmpDaoImpl() throws EmpException {
		util = new EntityManageUtil();
		manager = util.getManager();
	}

	private Emp getEmpDetails(int empno) throws EmpException {
		Emp emp = manager.find(Emp.class, empno);
		if (emp == null) {
			throw new EmpException("Wrong Empno!!!");
		}
		return emp;
	}

	public Emp getEmpDet(int empno) throws EmpException {
		Emp emp = manager.find(Emp.class, empno);
		if (emp == null) {
			throw new EmpException("Wrong Empno!!!");
		}
		manager.detach(emp);
		return emp;
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		try {
			TypedQuery<Emp> qry = manager.createNamedQuery("qryAllEmps", Emp.class);
			List<Emp> empList = qry.getResultList();

			return empList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new EmpException("Improper query fabrication");
		}
	}

	@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		try {
			manager.getTransaction().begin();
			manager.persist(emp);
			manager.getTransaction().commit();
		} catch (RollbackException e) {
			// TODO Auto-generated catch block
			throw new EmpException("Violated colmn size or constraint", e);
			// e.printStackTrace();
		}
		return emp;
	}

	@Override
	public boolean UpdateName(int empno, String newname) throws EmpException {
		try {
			manager.getTransaction().begin();
			Emp emp = this.getEmpDetails(empno);
			emp.setEmpname(newname);

			manager.getTransaction().commit();
			return true;
		} catch (RollbackException e) {
			// TODO Auto-generated catch block
			throw new EmpException("Failed name updation");
			// e.printStackTrace();
		}

	}

	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}

	@Override
	public boolean UpdateEmp(Emp emp) throws EmpException {
		manager.getTransaction().begin();
		manager.merge(emp);
		manager.getTransaction().commit();

		return false;
	}

	@Override
	public boolean Delete(int empno) throws EmpException {
		try {
			manager.getTransaction().begin();
			Emp emp = this.getEmpDetails(empno);
			manager.remove(emp);

			manager.getTransaction().commit();
			return true;
		} catch (RollbackException | EmpException e) {
			// TODO Auto-generated catch block
			throw new EmpException("Failed name updation");
			// e.printStackTrace();
		}

	}

	@Override
	public List<Emp> getEmpOnSal(float from, float to) throws EmpException {
		
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpOnSal", Emp.class);
		qry.setParameter("from", from);
		qry.setParameter("to", to);
		return qry.getResultList();

	}

	@Override
	public List<Emp> getEmpForComm() throws EmpException {
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpComm", Emp.class);
		return qry.getResultList();
	}

}
