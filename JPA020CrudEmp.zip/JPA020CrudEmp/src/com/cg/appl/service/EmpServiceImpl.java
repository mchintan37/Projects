package com.cg.appl.service;

import java.util.List;

import com.cg.appl.dao.EmpDaoImpl;
import com.cg.appl.dao.IEmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exception.EmpException;

public class EmpServiceImpl implements IEmpService {
	private IEmpDao dao;

	public EmpServiceImpl() throws EmpException {
		dao = new EmpDaoImpl();
	}

	public Emp getEmpDet(int empno) throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpDet(empno);
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpList();
	}

	@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		// TODO Auto-generated method stub
		return dao.admitNewEmp(emp);
	}

	@Override
	public boolean UpdateName(int empno, String newname) throws EmpException {
		// TODO Auto-generated method stub
		return dao.UpdateName(empno, newname);
	}

	@Override
	public boolean UpdateEmp(Emp emp) throws EmpException {
		// TODO Auto-generated method stub
		return dao.UpdateEmp(emp);
	}

	@Override
	public boolean Delete(int empno) throws EmpException {
		// TODO Auto-generated method stub
		return dao.Delete(empno);
	}

	@Override
	public List<Emp> getEmpOnSal(float from, float to) throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpOnSal(from, to);
	}

	@Override
	public List<Emp> getEmpForComm() throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpForComm();
	}

}
