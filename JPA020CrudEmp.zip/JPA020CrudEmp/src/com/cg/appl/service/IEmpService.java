package com.cg.appl.service;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exception.EmpException;

public interface IEmpService {
	Emp getEmpDet(int empno) throws EmpException;

	List<Emp> getEmpList() throws EmpException;

	Emp admitNewEmp(Emp emp) throws EmpException;

	boolean UpdateName(int empno, String newname) throws EmpException;

	boolean UpdateEmp(Emp emp) throws EmpException;

	boolean Delete(int empno) throws EmpException;

	List<Emp> getEmpOnSal(float from, float to) throws EmpException;
	
	List<Emp> getEmpForComm() throws EmpException;
}
