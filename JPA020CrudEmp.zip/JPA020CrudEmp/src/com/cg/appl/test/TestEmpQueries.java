package com.cg.appl.test;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exception.EmpException;
import com.cg.appl.service.EmpServiceImpl;
import com.cg.appl.service.IEmpService;

public class TestEmpQueries {

	public static void main(String[] args) throws EmpException {
		try {
			IEmpService services=new EmpServiceImpl();
			
List<Emp> empList=services.getEmpList();
			
			for(Emp empl :empList)
			{
			System.out.println(empl);
			}
		/*	List<Emp> empList=services.getEmpForComm();
			
			for(Emp empl :empList)
			{
			System.out.println(empl);
			}*/
			
			//Emp emp=new Emp();
			//emp.setEmpname("Boby");
			//emp.setEmpsal(2000f);
			//emp=services.admitNewEmp(emp);
			//System.out.println(emp);
			
			
			//List<Emp> empList=services.getEmpOnSal(2000, 5000);
			
			//for(Emp empl :empList)
			//{
			//System.out.println(empl);
			//}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
