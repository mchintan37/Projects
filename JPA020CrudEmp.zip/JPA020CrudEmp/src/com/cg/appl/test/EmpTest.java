package com.cg.appl.test;

import com.cg.appl.entities.Emp;
import com.cg.appl.exception.EmpException;
import com.cg.appl.service.EmpServiceImpl;
import com.cg.appl.service.IEmpService;

public class EmpTest {

	public static void main(String[] args) throws EmpException {
		try {
			IEmpService services = new EmpServiceImpl();

			//Emp emp = services.getEmpDetails(7499);
			//System.out.println(emp);
			
			for(Emp empl :services.getEmpList())
			{
			System.out.println(empl);
			}	
			
			
			
			/*Emp emp=new Emp();
			emp.setEmpno(1112);
			emp.setEmpname("Starcc");
			emp.setEmpsal(2000f);
			services.admitNewEmp(emp);
			System.out.println(services.getEmpDetails(1112));*/
			
			//services.UpdateName(7499, "Okayyy");
			
		/*	Emp emp=new Emp();
			emp.setEmpno(7499);
			emp.setEmpname("Mitchell");
			emp.setEmpsal(2500f);
			System.out.println(emp);
			
			services.UpdateEmp(emp);*/
			
			//services.Delete(200);
			//System.out.println(services.getEmpDet(200));
			
		} catch (EmpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
