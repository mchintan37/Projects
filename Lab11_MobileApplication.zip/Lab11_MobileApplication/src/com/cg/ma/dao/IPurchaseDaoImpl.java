package com.cg.ma.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.JdbcUtil.JdbcUtil;
import com.cg.ma.dao.IPurchaseDao;

import com.cg.ma.dto.PurchaseDetails;

public class IPurchaseDaoImpl implements IPurchaseDao{
	Connection conn=null;
	PreparedStatement ps=null;
	@Override
	public int addPurchaseDetails(PurchaseDetails purchase)
			throws MobileException {
		
		int pId=0;
		
		String query="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
		try {
			pId=getPurchaseId();
			
			conn=JdbcUtil.getConnection();
			ps=conn.prepareStatement(query);
			ps.setInt(1,pId);
			ps.setString(2,purchase.getCname());
			ps.setString(3,purchase.getMailid());
			ps.setString(4,purchase.getPhoneno());
			
			Calendar calendar = Calendar.getInstance();
		    java.sql.Date currentDate = new java.sql.Date(calendar.getTime().getTime());
	    	 ps.setDate(5, currentDate);
			
			ps.setInt(6, purchase.getMobileid());
			int status=ps.executeUpdate();
			if(status==1)
			System.out.println("Data Inserted Successfully");
		}
			catch (SQLException e) {
				
				throw new MobileException("Data Not Inserted..");
			}
		finally
		{
			
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return pId;
	}

	private int getPurchaseId() throws MobileException {
		int id=0;
		String query="SELECT purchase_seq.NEXTVAL FROM DUAL";
		Connection conn=null;
		PreparedStatement ps=null;
		
		try {
			conn=JdbcUtil.getConnection();
			ps=conn.prepareStatement(query);
			ResultSet res=ps.executeQuery();
			while(res.next()){
			id=res.getInt(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return id;

	
	}
	
	@Override
	public List<PurchaseDetails> showPurchaseDetails() throws MobileException {
		List<PurchaseDetails> purchaselist=new ArrayList<PurchaseDetails>();
		conn=JdbcUtil.getConnection();
		String query="SELECT * from purchasedetails";
		try {
			ps=conn.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				PurchaseDetails pdetails=new PurchaseDetails();
			
				pdetails.setPurchaseid(rs.getInt("purchaseid"));
				pdetails.setCname(rs.getString("cname"));
				pdetails.setMailid(rs.getString("mailid"));
				pdetails.setPhoneno(rs.getString("phoneno"));
				pdetails.setPurchasedate(rs.getDate("purchasedate"));
				pdetails.setMobileid(rs.getInt("mobileid"));
				purchaselist.add(pdetails);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobileException("Data Not Found");
		}
		finally
		{
			
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return purchaselist;
	}

	

}
