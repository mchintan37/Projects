package com.cg.ma.service;

import java.util.List;
import java.util.regex.Pattern;


import com.cg.ma.Exception.MobileException;

import com.cg.ma.dao.IPurchaseDao;
import com.cg.ma.dao.IPurchaseDaoImpl;
import com.cg.ma.dto.PurchaseDetails;

public class IPurchaseServiceImpl implements IPurchaseService{
	IPurchaseDao purchasedao=new IPurchaseDaoImpl();
	@Override
	public int addPurchaseDetail(PurchaseDetails purchase) throws MobileException
	{
		return purchasedao.addPurchaseDetails(purchase);
		
		
	}
	
	
	public List<PurchaseDetails> showPurchaseDetail() throws MobileException
	{
		return purchasedao.showPurchaseDetails();
		
	}
	public static void validateName(String patt,String name) throws MobileException{
	boolean value=Pattern.matches(patt,name);
	if(!value){
		throw new MobileException("Name should be min3 max 10 First letter capital");
	}
		
	}
	public static void validatePhoneno(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("PhoneNo must be of 10 digits");
		}
			
		}
	public static void validateMailid(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("Please Enter Valid Email id");
		}
			
		}
	public static void validateMobilId(String patt,String name) throws MobileException{
		boolean value=Pattern.matches(patt,name);
		if(!value){
			throw new MobileException("MobileId should be of 4 digits");
		}
			
		}
}
