package com.cg.ma.service;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.PurchaseDetails;

public interface IPurchaseService {
	public int addPurchaseDetail(PurchaseDetails purchase) throws MobileException;
	public List<PurchaseDetails> showPurchaseDetail() throws MobileException;
}
