package com.cg.ma.service;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dto.MobileDetails;

public interface IMobileService {
	List<MobileDetails> ShowAll() throws MobileException ; 
	boolean DeleteMobileDetails(int mobileid) throws MobileException;
	List<MobileDetails> SearchPrice(double minprice,double maxprice) throws MobileException;
	boolean UpdateQtyService(int mobileid,double qty) throws MobileException;
}
