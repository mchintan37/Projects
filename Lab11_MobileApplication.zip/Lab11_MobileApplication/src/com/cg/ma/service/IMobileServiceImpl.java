package com.cg.ma.service;

import java.util.List;

import com.cg.ma.Exception.MobileException;
import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.IMobileDaoImpl;
import com.cg.ma.dto.MobileDetails;

public class IMobileServiceImpl implements IMobileService {
	IMobileDao mobiledao=new IMobileDaoImpl();
	public List<MobileDetails> ShowAll() throws MobileException {
		return mobiledao.ShowMobileData();
		
	} 
	public boolean DeleteMobileDetails(int mobileid) throws MobileException
	{
		return mobiledao.RemoveMobileDetails(mobileid);
	
		
	}
	public List<MobileDetails> SearchPrice(double minprice,double maxprice) throws MobileException
	{
		return mobiledao.SearchByPrice(minprice, maxprice);
		
	}
	public boolean UpdateQtyService(int mobileid, double qty)
			throws MobileException {
		// TODO Auto-generated method stub
		return mobiledao.UpdateQty(mobileid, qty);
	}
}
