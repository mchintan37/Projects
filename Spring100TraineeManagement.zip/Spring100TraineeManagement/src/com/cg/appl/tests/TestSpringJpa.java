package com.cg.appl.tests;

import org.springframework.context.ConfigurableApplicationContext;




import com.cg.appl.service.TraineeService;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.util.SpringUtil;

public class TestSpringJpa {

	public static void main(String[] args) {
	SpringUtil util=new SpringUtil();
	
	ConfigurableApplicationContext ctx=util.getSpringContext();
	TraineeService service= ctx.getBean("traineeService",TraineeService.class);

	Trainee trainee;
	try {
		trainee = service.getTraineeDetails(1000);
		System.out.println(trainee);
	} catch (TraineeException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	ctx.close();
	}
	

}
