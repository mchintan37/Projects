package com.cg.appl.service;

import javax.annotation.Resource;




import org.springframework.stereotype.Service;

import com.cg.appl.dao.TraineeDao;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
@Service("traineeService")
public class TraineeServiceImpl implements TraineeService {

	private TraineeDao dao;
	
	@Resource(name="traineeDao")
	public void setDao(TraineeDao dao) {
		this.dao = dao;
	}


	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {

		return dao.getTraineeDetails(traineeId);
	}

}
