package com.cg.appl.service;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

public interface TraineeService {
	Trainee getTraineeDetails(int traineeId) throws TraineeException;
}
