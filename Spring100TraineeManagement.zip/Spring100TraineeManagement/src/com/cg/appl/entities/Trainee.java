package com.cg.appl.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "trainee")
@Table(name = "TRAINEE")
public class Trainee {
	private int traineeId;
	private String traineeName;
	private String traineeLocation;
	private String traineeDomain;

	public Trainee() {
	

	}

	@Id
	@Column(name="TRAINEEID")
	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	@Column(name="TRAINEENAME")
	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	@Column(name="TRAINEELOCATION")
	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	@Column(name="TRAINEEDOMAIN")
	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeLocation=" + traineeLocation
				+ ", traineeDomain=" + traineeDomain + "]";
	}

}
