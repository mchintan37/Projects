package com.cg.appl.dao;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDao {
	private EntityManagerFactory factory;

	@Resource(name = "entityManagerFactory")
	public void setFactory(EntityManagerFactory factory) {
		this.factory = factory;
	}

	

	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		EntityManager manager = factory.createEntityManager();
		Trainee trainee = manager.find(Trainee.class, traineeId);
		if(trainee!=null)
		{
			System.out.println("record found");
			return trainee;
		}
		else
		{
			System.out.println("not found");
			return null;
		}
		
	}

}
