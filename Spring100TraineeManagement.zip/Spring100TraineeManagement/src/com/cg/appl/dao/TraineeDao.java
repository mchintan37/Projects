package com.cg.appl.dao;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

public interface TraineeDao {

	Trainee getTraineeDetails(int traineeId) throws TraineeException;
}
